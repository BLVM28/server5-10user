# KWT 本科任务 1 和任务 2 RTL 工程

本工程实现固定形状 `Y[99,256] = X[99,64] × W[64,256] + b[256]`，支持逐任务更换 12 层参数。采用 8 路串行点积、完整 X 缓存、8 列 W 缓存和单笔在途 ICB 访问。算术、矩阵、NICE 协议与真实 SRAM 功能模型已有通过记录；正式 E203 整机、共享内存映射和 ASIC 时序面积仍须完成平台验收。

任务边界依据赛题印刷 p6—8、`transformer_utils.py:87–118`：X 是 Attention、残差与第一次 LayerNorm 后的 `out1`，Y 是第一 Dense 加偏置后、GELU 前。12 次独立线性任务不能连接成 `Y → 下一层 X`。Attention、GELU、第二 Dense、完整分类链路不属于本工程实现的必做任务 1/2。

## 从哪里开始

| 文件 | 用途 |
|---|---|
| [实现规格](implementation_spec.md) | 模块关系、数值、循环、地址、握手与异常契约 |
| [E203 接入说明](integration/README.md) | 实际端口、替换位置、内存配置、驱动与复位条件 |
| [验证报告](validation.md) | 通过记录、失败原因、测试边界和待完成工作 |
| `rtl/`、`rtl.f` | 10 个平台分层的 SystemVerilog 源文件 |
| `tb/`、`sim.f` | 独立算术、总线、矩阵、真实宏测试平台 |
| `py/` | checkpoint 导出、独立数值模型、原模型输入提取、仿真脚本 |
| `vec/weights/` | 指定 checkpoint 的 12 层第一 Dense 参数及身份记录 |
| `vec/activation_smoke/` | 原模型静音/音调检查与静音的 12 层 RTL 向量 |
| `build/` | 实际编译、仿真和结构检查日志；不用截图替代日志计数 |

## 本地复现

以下命令均在 `v1` 目录执行。已提供向量，RTL 仿真不要求安装 TensorFlow。Windows 使用已安装的 Vivado Simulator：

```powershell
python py/run_xsim.py --tag rerun
python py/run_xsim.py --tops tb_kwt_system --tag rerun_swap --define KWT_TEST_SWAP --define KWT_TEST_W1024
python py/run_xsim.py --tops tb_kwt_system --tag rerun_activation --vectors vec/activation_smoke/rtl
```

脚本默认工具位置 `D:/vivado/Vivado/2023.2/bin`，可用 `--bin` 修改。日志必须同时满足进程成功、出现 `ALL PASS, N/N` 且没有 fatal；VCS 的 `$fatal` 曾返回 exit 0，因此不能只看退出码。

Linux VCS 与 Xcelium：

```bash
bash run.sh --sim vcs --tag vcs
bash run.sh --sim vcs --tag vcs_macro --tops tb_kwt_system --foundry /storage1/admin_public_dir/SRAM_Lib_2025
bash 06_xcelium/run.sh
```

Xcelium 脚本尚未在 Xcelium 实机执行。服务器上使用项目自带的 `py/run_foundry_server.py` 和 `py/run_binding_server.py` 得到了 VCS 真实宏记录；这两份脚本固定限制在授权个人 home 下，不下载或改写公共模型。

## 数值模型与输入

`py/numeric_model.py` 使用 Python `Fraction` 的数学舍入建立独立 RNE 参考，整数矩阵累加使用 int64。RTL 中间和为 40 位，不逐项截断。`export_weights.py` 检查 checkpoint 两个文件的 SHA-256，再读取明确的第一 Dense 键，禁止静默替换权重。

```powershell
python py/export_weights.py --checkpoint ../01_核心参考/keyword-transformer-master/models_data_v2_12_labels/kwt1/best_weights --output vec/weights
python py/make_vectors.py
```

上述 `python` 需有 TensorFlow；或使用 `--reader-deps` 指向本地独立 checkpoint reader 依赖。当前提供的参数已实际导出并经 TensorFlow 加载值复核，无需重复导出。

原模型验证使用 Python 3.8 和 `requirements-tf24.txt`。仓库要求的 TensorFlow 2.4.0rc1 当前 PyPI 无法安装，本工程实测使用 2.4.0，保留这一差异。运行以下命令会创建自己的结果目录，不修改原模型代码：

```powershell
python py/capture_activations.py --smoke --out vec/activation_smoke
python py/capture_activations.py --manifest validation_manifest.json --out vec/validation_inputs
```

manifest 是 `[{"path":"...wav","split":"validation","label":"yes"}, ...]`。只允许 training/validation 标记，必须由调用者按官方划分提供真实清单；脚本不会把用户标签当成经过验证的官方划分。文件须为单声道、16 kHz、16 bit PCM、长度不超过 1 秒；补零后经原 SpeechFeatures 层。它不是官方完整数据选择器，不处理长音频裁剪。`--smoke` 的合成音调不属于语音验证样本。

## 部署前必须配置

正式 `MEM_BASE` 和 `MEM_BYTES` 默认均为 0，任务会被拒绝。`0x10000000` 仅是测试平台地址，禁止当成公共 E203 的已接通 SRAM。公共包的 `sysper/sysfio/sysmem` 顶层均为读零占位连接，ITCM 与 DTCM 的两个 256 KiB 配置也不能证明题目 512 KiB 共享存储已经存在。

需落实：可由 CPU/NICE 共同访问的真实 RAM 及合法分配范围、字序与一致性、长指令及错误处理、整域复位、正式顶层/filelist。取得这些信息后替换参数与平台互联，再执行真实 CPU 程序和 ASIC 综合验收。具体处理见接入说明和验证报告。

## 来源

赛题原文与参考仓库保持只读。模型参考为本地固定 ARM keyword-transformer `237e4097`，上游许可证见原仓库 `LICENSE.txt`；权重派生文件保留来源，未训练、微调或蒸馏。公共 E203 ZIP 与 SRAM 模型在服务器原地读取/编译，未把公共源文件放入本地交付。旧 S1 源文件缺失，本工程的 dot64 和软件模型是按已记录契约重建，不能称为恢复或复用原 S1 源码。

## 后续服务器 EDA 实测

原交付材料已上传个人工作目录的 `kwt_eda_tmp_20261101/project`，新增 [server_eda/Makefile](server_eda/Makefile)、TB、DC/PT 脚本。VCS 功能回归、1186 项 SRAM 检查与 32 向量 dot64 SDF 门级仿真通过。实际 SMIC40 库综合和 SS/FF 布局前 STA 已完成，但完整核心有 hold 负余量，150 MHz 未验收。完整结果、时序路径、复现方法与限制见 [server_eda/RESULTS.md](server_eda/RESULTS.md)。本轮没有改变设计 RTL 或数值契约。

`MANIFEST.json` 对应保留的原始 `dist/kwt_rtl_v1.zip`；本轮新增测试环境、实测记录及更新说明的哈希见 `MANIFEST_EDA.json`，增补包为 `dist/kwt_server_eda_addendum_20261101.zip`。原包未覆盖。
