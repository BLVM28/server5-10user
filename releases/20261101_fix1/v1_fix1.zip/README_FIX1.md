# fix1 implementation and VM validation bundle

This archive contains one version's own source under work/, shared scripts
under flow/, and its GPDK045 results under results/. Installations, licenses,
foundry libraries and server netlists are NOT included.

The existing VM workspace is /home/eda/kwt_vm_20261101. No extraction is
needed there: work and flow are already installed. To rerun this version:

    cd /home/eda/kwt_vm_20261101
    make -C flow v1

Both archives are needed for `make -C flow -j2 all` or `make -C flow check`.
Do not extract over unrelated projects. env.sh is specific to this VM.
See flow/REPORT.md for the Chinese final report and flow/README.md for usage.

results/*/synth_dot and sta_slow/sta_fast are the BEFORE-ECO baseline,
including known violations. FINAL maps are eco_dot/mapped.v; FINAL timing
is sta_eco_slow/sta_eco_fast; FINAL gates are gate_eco_slow/gate_eco_fast.
summary.json is the authoritative limited-scope result. Original SDF and
conservative compatibility SDF are both retained and independently audited.
Source manifests and reports inside work/ are historical; this archive's
MANIFEST.json identifies the current contents. Failed iterations remain
in the VM history and the separately preserved final_vm_evidence.zip.

The RTL is byte-identical to the frozen original. No new cycle speedup is
claimed. Full CPU/full speech model and physical signoff remain incomplete.
