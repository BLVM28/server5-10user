# v1 / v2 交付索引

日期：2026-11-01。报告：[v1/v2 对比](../../v2/REPORT_V1_V2.md)；架构：[改良依据](../../v2/ARCHITECTURE_V2.md)；复现：[服务器 Makefile 说明](../../v2/server_eda/README.md)。

| 本地冻结包 | 文件数（不含 RELEASE_MANIFEST 自身） | bytes | SHA-256 |
|---|---:|---:|---|
| [v1.zip](v1.zip) | 488 | 11278469 | 1e814b7c3235597cc650893bd0d9ca6569fc9a4521ab1e6441d829c32112932c |
| [v2.zip](v2.zip) | 279 | 9687599 | bface62133c296d5294ffb98133159ca8a6b2b8272f99b1efde7d9d8e442fbcc |

服务器对应包位于 `/storage2/2026contest/server5/s5_10usr/kwt_versions_20261101/`：

| 服务器包 | 文件数 | bytes | SHA-256 |
|---|---:|---:|---|
| v1.zip | 394 | 11453218 | 995260172e00f950eecda90c979e1008239e09d88f3278fb1049dcf94b4054ea |
| v2.zip | 676 | 26774276 | efbaccda02a59f2deb633a4de74d5e5dbd4d7c9ed990525c9fc1c49056f4d023 |

服务器数值来自 VNC 可见回显并按 8 位分组复核，记录截图 `过程与分析/05_工具/V2优化_20261101/34_server_packages_final.png`，不是下载的服务器文件。两地 CRC 与包内逐文件 manifest 均已验证；279 个本地 v2 发布文件上传后逐文件核对，测试过的 RTL 未改变。

包的内容因本地/服务器证据不同而不同：服务器包含实际 DC/PT 报告、映射网表、SDF、DDC；本地包含源码、向量、本地仿真日志和标明来源的观察摘要。可执行文件、编译缓存、公共工艺库不在最终 v2 包中。两地 v1 原包保留，工作区 v1 的 488 个原文件未改。

其余 candidate/flow/full_gate ZIP 是过程补丁，最终使用上面两个无后缀版本包。功能与门级测试通过；v2 仍有两处电容违例、极小 setup 余量和后端/SoC/语音验收缺项，详细限定见报告。
