from pathlib import Path
import os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_fixes_20261101';w.mkdir(exist_ok=True);(w/'tmp').mkdir(exist_ok=True)
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
p=w/'query.tcl';p.write_text('help -verbose compile\nhelp -verbose set_max_capacitance\nexit\n')
with (w/'query.log').open('w') as f:r=subprocess.run(['dc_shell','-f',str(p)],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT)
print('DC_QUERY_EXIT',r.returncode)
for line in (w/'query.log').read_text().splitlines():
 if any(s in line for s in ['only_design_rule','only_hold_time','incremental_mapping','set_max_capacitance','object_list','Error:']):print(line)
