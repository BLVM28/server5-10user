set -eu
cd /home/eda/kwt_vm_20261101
source flow/env.sh
python3 - <<'PY' > evidence/eco_inspect.txt
from pathlib import Path
import re
r=Path('/home/eda/kwt_vm_20261101')
for v in ['v1','v2']:
 for c in ['slow','fast']:
  s=(r/'results'/v/('sta_'+c)/'constraints.rpt').read_text()
  pts=re.findall(r'^\s*(\S+)\s+[rf]\s+(-[\d.]+)\s+VIOLATED',s,re.M)
  print(v,c,'VIOLATIONS',len(pts),'PINS',sorted(set(p.rsplit('/',1)[-1] for p,n in pts)))
  print('NON_RESET',[(p,n) for p,n in pts if not p.endswith('/RN')])
s=(r/'results/v2/synth_dot/mapped.v').read_text()
print('DRIVER',re.search(r'^.*g5088__9945\s*\([\s\S]*?;',s,re.M).group(0))
lib=Path('/opt/eda2/gpdk045/gsclib045_all_v4.4/gsclib045/timing/slow_vdd1v0_basicCells.lib').read_text()
for name in ['BUFX2','BUFX4','INVX1','INVX2']:
 m=re.search(r'cell\s*\(\s*'+name+r'\s*\)',lib)
 if not m:print(name,'MISSING');continue
 start=lib.index('{',m.end());i=start+1;depth=1
 while depth:
  if lib[i]=='{':depth+=1
  if lib[i]=='}':depth-=1
  i+=1
 cell=lib[start:i]
 print(name,'FOUND')
 for line in cell.splitlines():
  if any(x in line for x in ['pin (','function','capacitance','area :']):print(line.strip())
PY
mkdir -p evidence/eco_probe
cd evidence/eco_probe
tempus -no_gui -files /home/eda/kwt_vm_20261101/flow/probe_eco.tcl > probe.log 2>&1
