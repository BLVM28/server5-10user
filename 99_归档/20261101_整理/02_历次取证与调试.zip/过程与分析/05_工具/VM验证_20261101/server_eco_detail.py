from pathlib import Path
import json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_fixes_20261101';r=h/'kwt_versions_20261101/v2'
print((w/'eco_job.log').read_text()[:600])
p=r/'build/v2_eco/synth_kwt_nice_core/dc.log'
for s in p.read_text().splitlines():
 if s.startswith(('Error:','ECO_SIZED','ECO_REPAIR_COMPLETE')):print(s)
for v,tag in [('v1','v1_reset'),('v2','v2_eco')]:
 for p in sorted((r/'build'/tag).glob('sta_*/metrics.txt')):print(v,p.parent.name,p.read_text().strip())
 for p in sorted((r/'build'/tag).glob('sta_*/violations.rpt')):
  lines=[s.strip() for s in p.read_text().splitlines() if 'VIOLATED' in s];print('DRC',v,p.parent.name,len(lines),' | '.join(lines))
 for p in sorted((r/'build'/tag).glob('synth_*/area.rpt')):
  for s in p.read_text().splitlines():
   if 'Total cell area' in s:print('AREA',v,p.parent.name,s)
print('TAIL', (w/'eco_job.log').read_text()[-800:])
