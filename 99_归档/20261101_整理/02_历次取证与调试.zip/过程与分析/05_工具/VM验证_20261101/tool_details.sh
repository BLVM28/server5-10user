set -eu
r=/home/eda/kwt_vm_20261101
cd "$r"
python "$r/scripts/bootstrap.py" > "$r/evidence/bootstrap.log" 2>&1
{
 printf 'DIGITAL_SETUP\n';cat /opt/eda2/setup/u.digital.cshrc
 printf '\nLICENSE_ENV_SETUP\n';cat /opt/eda2/setup/lic.cshrc
 printf '\nGENUS_EXAMPLE\n';cat /home/eda/ALU_Genus_Innovus_Flow/SCRIPTS/genus_run.tcl
 printf '\nMMMC_EXAMPLE\n';cat /home/eda/ALU_Genus_Innovus_Flow/SCRIPTS/mmmc_setup.tcl
 printf '\nGPDK_LIBS\n';find /opt/eda2/gpdk045 -maxdepth 5 -type f \( -name '*.lib' -o -name '*.lib.gz' -o -name '*.v' \)
 printf '\nBUNDLED_PYTHON\n';/opt/eda2/cadence/XCELIUM2003/tools.lnx86/mce/python/bin/python3 --version
} > "$r/evidence/tool_details.txt" 2>&1
