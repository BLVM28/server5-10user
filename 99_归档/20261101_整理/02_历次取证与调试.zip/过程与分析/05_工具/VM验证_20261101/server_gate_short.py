from pathlib import Path
import json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
r=h/'kwt_versions_20261101/v2'
for tag in ['v1_reset','v2_eco5']:
 b=r/'build'/tag;p=b/'full_gate_result.json';print('TAG',tag)
 if p.exists():
  x=json.loads(p.read_text());print('COMPLETE',x['completed'],'STAGES',x['stages']);print('NETLIST_SHA',x['netlist_sha256']);print('SDF_SHA',x['sdf_sha256'])
 for name in ['run.log','sdf_annotation.log']:
  p=b/'full_gate'/name
  if p.exists():
   for s in p.read_text(errors='replace').splitlines():
    if any(x in s for x in ['ALL PASS','matrix gate','Total errors:','Total warnings:','SDF annotation completed:']):print(s)
