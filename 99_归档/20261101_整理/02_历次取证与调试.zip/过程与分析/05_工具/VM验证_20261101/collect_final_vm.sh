set -euo pipefail
cd /home/eda/kwt_vm_20261101
source flow/env.sh
make -C flow check > evidence/final_check.log 2>&1
make -C flow -n -j2 all > evidence/make_dryrun.log 2>&1
python3 - <<'PY'
from pathlib import Path
import zipfile,hashlib,json
r=Path('/home/eda/kwt_vm_20261101');files=[]
for v in ['v1','v2']:
 for p in (r/'results'/v).rglob('*'):
  rel=p.relative_to(r/'results'/v)
  if not p.is_file() or any(x in ['xcelium.d','fv','work'] for x in rel.parts):continue
  if p.suffix in ['.json','.log','.rpt','.sdf','.sdc','.txt','.failed'] or p.name=='mapped.v':files.append(p)
 for tag in ['vm_default','vm_fallback','vm_activation']:
  for p in (r/'work'/v/'build'/tag).glob('*'):
   if p.is_file() and p.suffix in ['.log','.json']:files.append(p)
for name in ['final_check.log','make_dryrun.log','upload_verified.json','regression_v1.log','regression_v2.log','gate_v1_r4.log','gate_v2_r4.log']:
 files.append(r/'evidence'/name)
manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
target=r/'evidence/final_vm_evidence.zip'
with zipfile.ZipFile(str(target),'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(str(p),str(p.relative_to(r)))
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(str(target)) as z:
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
(r/'evidence/final_vm_evidence.sha256').write_text(hashlib.sha256(target.read_bytes()).hexdigest()+'  final_vm_evidence.zip\n')
PY
