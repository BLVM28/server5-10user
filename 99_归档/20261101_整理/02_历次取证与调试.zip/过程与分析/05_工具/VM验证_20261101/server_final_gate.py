from pathlib import Path
import subprocess,os
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
r=h/'kwt_versions_20261101/v2';w=h/'kwt_fixes_20261101'
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
for tag in ['v1_reset','v2_eco5']:
 assert not (w/(tag+'_full_gate.log')).exists()
 with (w/(tag+'_full_gate.log')).open('w') as f:
  p=subprocess.Popen(['python3','full_gate.py','--tag',tag],cwd=str(r/'server_eda'),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print('FINAL_GATE',tag,p.pid)
