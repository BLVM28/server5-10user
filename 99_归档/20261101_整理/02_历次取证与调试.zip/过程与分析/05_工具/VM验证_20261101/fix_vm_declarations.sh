set -eu
cd /home/eda/kwt_vm_20261101
source flow/env.sh
python3 - <<'PY'
from pathlib import Path
import re,hashlib,json,shutil
r=Path('/home/eda/kwt_vm_20261101')
for v in ['v1','v2']:
 d=r/'results'/v/'eco_dot';p=d/'mapped.v';s=p.read_text()
 m=re.search(r'^  wire kwt_eco_[^;]+;\n',s,re.M);assert m
 declaration=m.group(0);s=s[:m.start()]+s[m.end():]
 header=re.search(r'\bmodule\s+kwt_dot64\s*\([\s\S]*?\);',s);assert header
 s=s[:header.end()]+'\n'+declaration+s[header.end():]
 shutil.copy2(str(p),str(d/'mapped_late_declaration.v.failed'))
 shutil.copy2(str(d/'changes.json'),str(d/'changes_late_declaration.json.failed'))
 p.write_text(s)
 rec=json.loads((d/'changes.json').read_text());rec['output_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();rec['declaration_order_corrected']=True
 (d/'changes.json').write_text(json.dumps(rec,indent=2)+'\n')
PY
for v in v1 v2; do
 (python3 flow/recheck_current.py "$v" && python3 flow/run_gate.py "$v" --eco --corner slow && python3 flow/run_gate.py "$v" --eco --corner fast) > evidence/gate_${v}_r2.log 2>&1 </dev/null &
done
