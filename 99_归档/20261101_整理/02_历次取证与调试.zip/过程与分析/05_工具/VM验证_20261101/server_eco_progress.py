from pathlib import Path
import re,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_fixes_20261101';r=h/'kwt_versions_20261101/v2'
print('EXIT',(w/'eco_exit.json').read_text() if (w/'eco_exit.json').exists() else 'RUNNING_OR_FAILED')
print((w/'eco_job.log').read_text()[-1500:])
for v in ['v1','v2']:
 for p in (r/'build'/(v+'_drc')).glob('sta_*/metrics.txt'):print(v,p.parent.name,p.read_text().strip())
 for p in (r/'build'/(v+'_drc')).glob('sta_*/violations.rpt'):
  rows=[s.strip() for s in p.read_text().splitlines() if 'VIOLATED' in s]
  print('DRC',v,p.parent.name,len(rows),' | '.join(rows[:5]))
 for p in (r/'build'/(v+'_drc')).glob('synth_*/area.rpt'):print('AREA',v,p.parent.name,*[s.strip() for s in p.read_text().splitlines() if 'Total cell area:' in s])
