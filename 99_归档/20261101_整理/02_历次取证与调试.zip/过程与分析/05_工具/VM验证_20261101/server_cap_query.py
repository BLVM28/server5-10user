from pathlib import Path
import json,os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_fixes_20261101';r=h/'kwt_versions_20261101/v2';libs=json.loads((r.parent/'library_selection.json').read_text())
t='''set_app_var link_library [concat [list * $env(STD)] [split $env(RAMS) |]]
read_ddc $env(DDC)
current_design kwt_nice_core
link
foreach n {master/U381 U1770} {
 set c [get_cells $n]
 set ref [get_attribute $c ref_name]
 puts "TARGET $n REF $ref"
 set lc [get_lib_cells */$ref]
 foreach_in_collection p [filter_collection [get_lib_pins -of_objects $lc] "direction == out"] {
  puts "PIN [get_object_name $p] CAP [get_attribute $p max_capacitance]"
 }
}
help -verbose size_cell
exit
'''
(w/'cap_query.tcl').write_text(t);env=os.environ.copy();env.update({'STD':libs['standard']['ss'],'RAMS':'|'.join(libs['sram']['ss']),'DDC':str(r/'build/v2_reset/synth_kwt_nice_core/mapped.ddc')})
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
with (w/'cap_query.log').open('w') as f:p=subprocess.run(['dc_shell','-f',str(w/'cap_query.tcl')],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT)
print('QUERY_EXIT',p.returncode)
for s in (w/'cap_query.log').read_text().splitlines():
 if s.startswith(('TARGET','PIN','Error:','size_cell')):print(s)
print('DRC_JOB_TAIL\n'+(w/'drc_job.log').read_text()[-800:])
