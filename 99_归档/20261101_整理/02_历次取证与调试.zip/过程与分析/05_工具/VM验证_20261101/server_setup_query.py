from pathlib import Path
import os,json,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
r=h/'kwt_versions_20261101/v2';w=h/'kwt_fixes_20261101'
p=r/'build/v2_eco2/sta_kwt_nice_core_ss'
print('FILES',*[x.name for x in p.glob('*.rpt')])
for f in ['setup.rpt','max.rpt']:
 q=p/f
 if q.exists():print(q.read_text()[:9500])
