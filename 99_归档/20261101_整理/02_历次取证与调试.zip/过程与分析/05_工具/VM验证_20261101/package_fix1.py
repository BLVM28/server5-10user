"""Package own sources and private-VM evidence without touching frozen releases."""
from pathlib import Path
import ast, hashlib, json, zipfile

R=Path(__file__).resolve().parents[3]
OUT=R/'releases/20261101_fix1';OUT.mkdir(parents=True,exist_ok=True)
E=R/'过程与分析/05_工具/VM验证_20261101/final_vm_evidence.zip'
old={'v1':'1e814b7c3235597cc650893bd0d9ca6569fc9a4521ab1e6441d829c32112932c','v2':'bface62133c296d5294ffb98133159ca8a6b2b8272f99b1efde7d9d8e442fbcc'}
for p in (R/'vm_eda').glob('*.py'):ast.parse(p.read_text(encoding='utf8'),filename=str(p))
with zipfile.ZipFile(E) as z:
    manifest=json.loads(z.read('MANIFEST.json'))
    for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
    for n in manifest:
        if n.startswith('work/') and '/build/' in n:
            v=n.split('/')[1];tail=n.split('/build/',1)[1]
            dest=R/'vm_eda/results'/v/'functional/raw'/tail
            assert not dest.exists()
            dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(n))

index={'date':'2026-11-01','vm_root':'/home/eda/kwt_vm_20261101','qualification':'See flow/REPORT.md; no full-model/CPU/post-route signoff.','packages':{}}
for v in ['v1','v2']:
    frozen=R/'releases/20261101_v2'/(v+'.zip')
    assert hashlib.sha256(frozen.read_bytes()).hexdigest()==old[v]
    summary=json.loads((R/'vm_eda/results'/v/'summary.json').read_text())
    assert summary['completed']
    with zipfile.ZipFile(frozen) as z:
        for p in (R/v/'rtl').glob('*.sv'):
            matches=[n for n in z.namelist() if n.endswith('/rtl/'+p.name) or n=='rtl/'+p.name]
            assert len(matches)==1
            assert p.read_bytes()==z.read(matches[0])
            assert hashlib.sha256(p.read_bytes()).hexdigest()==summary['rtl_sha256'][p.name]
    files={}
    for p in sorted((R/v).rglob('*')):
        rel=p.relative_to(R/v)
        if not p.is_file() or any(x in ['build','dist','__pycache__','.git'] for x in rel.parts):continue
        if p.suffix in ['.pyc','.zip']:continue
        files['work/'+v+'/'+rel.as_posix()]=p.read_bytes()
    for p in sorted((R/'vm_eda').rglob('*')):
        rel=p.relative_to(R/'vm_eda')
        if not p.is_file() or any(x in ['__pycache__','.git','history'] for x in rel.parts):continue
        if rel.parts[0]=='results':
            if rel.parts[1]!=v:continue
            name=rel.as_posix()
        else:name='flow/'+rel.as_posix()
        files[name]=p.read_bytes()
    files['README_FIX1.md']=('''# fix1 implementation and VM validation bundle

This archive contains one version's own source under work/, shared scripts
under flow/, and its GPDK045 results under results/. Installations, licenses,
foundry libraries and server netlists are NOT included.

The existing VM workspace is /home/eda/kwt_vm_20261101. No extraction is
needed there: work and flow are already installed. To rerun this version:

    cd /home/eda/kwt_vm_20261101
    make -C flow VERSION

Both archives are needed for `make -C flow -j2 all` or `make -C flow check`.
Do not extract over unrelated projects. env.sh is specific to this VM.
See flow/REPORT.md for the Chinese final report and flow/README.md for usage.

results/*/synth_dot and sta_slow/sta_fast are the BEFORE-ECO baseline,
including known violations. FINAL maps are eco_dot/mapped.v; FINAL timing
is sta_eco_slow/sta_eco_fast; FINAL gates are gate_eco_slow/gate_eco_fast.
summary.json is the authoritative limited-scope result. Original SDF and
conservative compatibility SDF are both retained and independently audited.
Source manifests and reports inside work/ are historical; this archive's
MANIFEST.json identifies the current contents. Failed iterations remain
in the VM history and the separately preserved final_vm_evidence.zip.

The RTL is byte-identical to the frozen original. No new cycle speedup is
claimed. Full CPU/full speech model and physical signoff remain incomplete.
'''.replace('make -C flow VERSION','make -C flow '+v)).encode()
    manifest={'version':v,'revision':'fix1','original_zip_sha256':old[v],'files':{n:hashlib.sha256(b).hexdigest() for n,b in files.items()}}
    target=OUT/(v+'_fix1.zip');assert not target.exists()
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items():z.writestr(n,b)
        z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(target) as z:
        assert set(z.namelist())==set(files)|{'MANIFEST.json'}
        for n,h in manifest['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h
    digest=hashlib.sha256(target.read_bytes()).hexdigest()
    index['packages'][v]={'file':target.name,'sha256':digest,'bytes':target.stat().st_size,'manifest_files':len(files)}
    (OUT/(target.name+'.sha256')).write_text(digest+'  '+target.name+'\n',encoding='utf8')
    print(v,index['packages'][v])
(OUT/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8')
