set -eu
task_root=/home/eda/kwt_vm_20261101
cd "$task_root"
export TMPDIR="$task_root/tmp"
{
 printf 'CSHRC\n';cat /home/eda/.cshrc
 printf '\nINSTALL_DIRECTORIES\n';find /opt/eda /opt/eda2 -maxdepth 3 -type d | head -140
 printf '\nUSER_FLOW_FILE_NAMES\n';find /home/eda/ALU_Genus_Innovus_Flow -maxdepth 3 -type f | head -70
 printf '\nTOOLS_EXECUTABLES\n';find /opt/eda /opt/eda2 -maxdepth 7 -type f \( -name xrun -o -name irun -o -name genus -o -name tempus -o -name innovus -o -name python3 -o -name dc_shell \) | head -60
 printf '\nLIBRARY_FILE_NAMES\n';find /opt/eda /opt/eda2 /home/eda/ALU_Genus_Innovus_Flow -type f \( -name '*.lib' -o -name '*.lib.gz' -o -name '*.db' \) | head -140
} > "$task_root/evidence/discover.txt" 2>&1
