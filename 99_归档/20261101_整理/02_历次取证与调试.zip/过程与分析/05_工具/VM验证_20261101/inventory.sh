set -eu
test "$(id -un)" = eda
test "$HOME" = /home/eda
task_root="$HOME/kwt_vm_20261101"
mkdir -p "$task_root/evidence" "$task_root/incoming" "$task_root/scripts" "$task_root/tmp"
cd "$task_root"
export TMPDIR="$task_root/tmp" TMP="$task_root/tmp" TEMP="$task_root/tmp"
{
 date -u
 id
 printf 'HOME=%s\nSHELL=%s\nPATH=%s\n' "$HOME" "$SHELL" "$PATH"
 cat /etc/redhat-release
 uname -a
 df -h "$task_root"
 free -m
 ip -4 addr show
 printf '\nTOOLS\n'
 for t in xrun irun ncvlog ncelab ncsim genus rtlcompiler rc innovus tempus dc_shell pt_shell lc_shell vcs vsim iverilog verilator yosys python3 python make; do command -v "$t" || true; done
 printf '\nTOP_LEVEL_INSTALL_LOCATIONS\n'
 for d in /opt /eda /tools /cad /cadence /synopsys /home/eda; do if test -d "$d"; then ls -la "$d" | head -60; fi; done
 printf '\nPROFILE_NAMES\n'
 for p in "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.cshrc" /etc/profile.d/*; do if test -f "$p"; then printf '%s\n' "$p"; fi; done
} > "$task_root/evidence/inventory.txt" 2>&1
