set -eu
r=/home/eda/kwt_vm_20261101
cd "$r"
{
 ls -l /opt/eda2/cadence/XCELIUM2003/bin/xrun /opt/eda2/cadence/XCELIUM2003/tools /opt/eda2/cadence/XCELIUM2003/tools.lnx86/inca/bin/xrun /opt/eda2/cadence/GENUS212/HOTFIX/bin/genus /opt/eda2/cadence/GENUS212/HOTFIX/tools.lnx86/bin/genus /opt/eda2/cadence/SSV211/bin/tempus
} > "$r/evidence/launchers.txt" 2>&1 || true
