"""VMware guest operations. Password stays in memory and is never logged."""
from pathlib import Path
import getpass,json,subprocess,sys,time
VMRUN=r'D:\VMware\vmrun.exe'
VMX=r'E:\IC_EDA_2025\IC_EDA_2025\IC_EDA_RH76.vmx'
password=getpass.getpass('VM guest password: ')
print(json.dumps({'ready':True}),flush=True)
for line in sys.stdin:
 try:
  q=json.loads(line);op=q['op']
  if op=='quit':break
  if op=='list':args=['listDirectoryInGuest',VMX,q['path']]
  elif op=='script':args=['runScriptInGuest',VMX,'/bin/bash',q.get('text') or Path(q['file']).read_text(encoding='utf-8')]
  elif op=='upload':args=['copyFileFromHostToGuest',VMX,q['local'],q['remote']]
  elif op=='download':
   assert q['remote'].startswith('/home/eda/kwt_vm_20261101/')
   Path(q['local']).parent.mkdir(parents=True,exist_ok=True)
   args=['copyFileFromGuestToHost',VMX,q['remote'],q['local']]
  else:raise ValueError('Unsupported operation')
  start=time.monotonic()
  r=subprocess.run([VMRUN,'-T','ws','-gu','eda','-gp',password]+args,capture_output=True,text=True,errors='replace',timeout=q.get('timeout',120))
  print(json.dumps({'op':op,'exit':r.returncode,'seconds':round(time.monotonic()-start,2),'output':(r.stdout+r.stderr)[-5000:]},ensure_ascii=True),flush=True)
 except Exception as e:print(json.dumps({'error':str(e).replace(password,'<redacted>')}),flush=True)
password=None
