from pathlib import Path
import json,hashlib,zipfile
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
r=h/'kwt_versions_20261101/v2';w=h/'kwt_fixes_20261101';out=w/'final';out.mkdir(exist_ok=True)
for v,tag in [('v1','v1_reset'),('v2','v2_eco5')]:
 b=r/'build'/tag
 sta=json.loads((b/'sta_result.json').read_text());gate=json.loads((b/'full_gate_result.json').read_text())
 assert sta['reported_constraints_met'] and sta['timing_slack_met'] and gate['completed']
 src=h/'kwt_eda_tmp_20261101/project' if v=='v1' else r
 files={}
 for p in src.rglob('*'):
  rel=p.relative_to(src)
  if p.is_file() and not any(x in ['build','dist','__pycache__','.git','server_eda'] for x in rel.parts):files[v+'/'+str(rel)]=p
 for p in (r/'server_eda').rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files[v+'/server_eda/'+str(p.relative_to(r/'server_eda'))]=p
 for p in b.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(b)
  if any(x in ['tmp','csrc','simv.daidir','work','prior_logs'] for x in rel.parts):continue
  if p.suffix in ['.rpt','.log','.json','.txt','.sdc','.tcl','.sdf','.ddc'] or p.name=='mapped.v':files[v+'/implementation/'+str(rel)]=p
 files[v+'/server_eda/fix1_cap_eco.tcl']=w/'cap_eco5.tcl'
 manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()}
 path=out/(v+'_fix1_smic40.zip');assert not path.exists()
 with zipfile.ZipFile(str(path),'w',zipfile.ZIP_DEFLATED) as z:
  for name,p in sorted(files.items()):z.write(str(p),name)
  z.writestr('MANIFEST.json',json.dumps({'version':v,'implementation_tag':tag,'scope':'own source and implementation artifacts; libraries excluded; server-only archive','files':manifest},indent=2))
 with zipfile.ZipFile(str(path)) as z:
  for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 print('VERIFIED',path,len(files),path.stat().st_size,hashlib.sha256(path.read_bytes()).hexdigest())
