set -eu
r=/home/eda/kwt_vm_20261101
cd "$r"
export TMPDIR="$r/tmp" TEMP="$r/tmp" TMP="$r/tmp"
{
 printf 'SETUP_FILES\n';ls /opt/eda2/setup
 for f in genus.212.cshrc xcelium.2003.cshrc ssv.211.cshrc; do if test -f /opt/eda2/setup/$f; then printf '\n%s\n' "$f";cat /opt/eda2/setup/$f;fi;done
 printf '\nPYTHON_TEST\n';LD_LIBRARY_PATH=/opt/eda2/cadence/XCELIUM2003/tools.lnx86/mce/python/lib /opt/eda2/cadence/XCELIUM2003/tools.lnx86/mce/python/bin/python3 --version
 printf '\nLIB_UNITS\n';grep -E 'library \(|time_unit|capacitive_load_unit|nom_voltage|nom_temperature|nom_process' /opt/eda2/gpdk045/gsclib045_all_v4.4/gsclib045/timing/{slow,fast}_vdd1v0_basicCells.lib | head -35
} > "$r/evidence/probe_tools.txt" 2>&1
