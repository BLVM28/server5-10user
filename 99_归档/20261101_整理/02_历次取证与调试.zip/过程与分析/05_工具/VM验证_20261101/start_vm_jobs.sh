set -eu
r=/home/eda/kwt_vm_20261101
cd "$r"
if ! test -f "$r/flow/env.sh"; then python -c "import zipfile;zipfile.ZipFile('incoming/vm_flow_r1.zip').extractall('flow')";fi
. "$r/flow/env.sh"
mkdir -p "$r/results" "$r/evidence/genus_probe" "$r/evidence/tempus_probe"
{
 python3 --version
 command -v xrun genus tempus
 xrun -version || true
 genus -version || true
 tempus -version || true
} > "$r/evidence/tool_versions.txt" 2>&1
for v in v1 v2; do
 (set +e;python3 "$r/flow/run_regression.py" "$v" > "$r/evidence/regression_$v.log" 2>&1;printf '%s\n' "$?" > "$r/evidence/regression_$v.exit") < /dev/null &
done
(cd "$r/evidence/genus_probe";genus -no_gui -batch -files "$r/flow/probe_genus.tcl" > probe.log 2>&1) < /dev/null &
(cd "$r/evidence/tempus_probe";tempus -no_gui -files "$r/flow/probe_tempus.tcl" > probe.log 2>&1) < /dev/null &
printf 'BACKGROUND_JOBS_STARTED\n'
