from __future__ import print_function
import os,json,hashlib,zipfile,shutil
ROOT='/home/eda/kwt_vm_20261101'
assert os.path.realpath(ROOT)==ROOT and os.environ['HOME']=='/home/eda'
expected={'v1':'1e814b7c3235597cc650893bd0d9ca6569fc9a4521ab1e6441d829c32112932c','v2':'bface62133c296d5294ffb98133159ca8a6b2b8272f99b1efde7d9d8e442fbcc'}
record={}
for v,digest in expected.items():
 archive=os.path.join(ROOT,'incoming',v+'.zip')
 with open(archive,'rb') as f:assert hashlib.sha256(f.read()).hexdigest()==digest
 dest=os.path.join(ROOT,'baseline',v);assert not os.path.exists(dest)
 os.makedirs(dest)
 with zipfile.ZipFile(archive) as z:
  manifest=json.loads(z.read(v+'/RELEASE_MANIFEST.json'))['sha256']
  for name,sha in manifest.items():
   assert not name.startswith('/') and '..' not in name.split('/')
   data=z.read(v+'/'+name);assert hashlib.sha256(data).hexdigest()==sha
   path=os.path.join(dest,name)
   if not os.path.isdir(os.path.dirname(path)):os.makedirs(os.path.dirname(path))
   with open(path,'wb') as f:f.write(data)
  with open(os.path.join(dest,'RELEASE_MANIFEST.json'),'wb') as f:f.write(z.read(v+'/RELEASE_MANIFEST.json'))
 work=os.path.join(ROOT,'work',v)
 shutil.copytree(dest,work,ignore=shutil.ignore_patterns('build','dist','__pycache__','RELEASE_MANIFEST.json'))
 record[v]={'zip_sha256':digest,'verified_files':len(manifest),'source':dest,'work':work}
with open(os.path.join(ROOT,'evidence/upload_verified.json'),'w') as f:json.dump(record,f,indent=2)
print('BOTH_PACKAGES_AND_MANIFESTS_VERIFIED')
