set -eu
r=/home/eda/kwt_vm_20261101
cd "$r"
python - <<'PY'
import os,json,zipfile
r='/home/eda/kwt_vm_20261101'
files=['evidence/tool_versions.txt','evidence/bootstrap.log','evidence/upload_verified.json','evidence/regression_v1.log','evidence/regression_v2.log','evidence/regression_v1.exit','evidence/regression_v2.exit','evidence/genus_probe/probe.log','evidence/tempus_probe/probe.log','results/v1/functional/results.json','results/v2/functional/results.json']
with zipfile.ZipFile(r+'/evidence/status.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in files:
  p=r+'/'+n
  if os.path.isfile(p):z.write(p,n)
PY
