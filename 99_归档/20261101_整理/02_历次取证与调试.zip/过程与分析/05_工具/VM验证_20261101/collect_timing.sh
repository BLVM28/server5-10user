set -eu
cd /home/eda/kwt_vm_20261101
/usr/bin/python - <<'PY'
import zipfile,glob,os
with zipfile.ZipFile('evidence/timing_status.zip','w',zipfile.ZIP_DEFLATED) as z:
 for pat in ['evidence/timing_*.log','evidence/timing_*.exit','evidence/eco_*.log','evidence/eco_*.exit','evidence/gate_*.log','evidence/gate_*.exit','results/v*/timing_run.json','results/v*/eco_run.json','results/v*/eco_dot/changes.json','results/v*/synth_dot/*.rpt','results/v*/synth_dot/tool.log','results/v*/synth_dot/exported.sdc','results/v*/sta_*/*.rpt','results/v*/sta_*/tool.log','results/v*/gate_*/*.log','results/v*/gate_*/results.json','results/v*/gate_*/sdf_stats.txt']:
  for p in glob.glob(pat):
   if os.path.isfile(p):z.write(p,p)
PY
