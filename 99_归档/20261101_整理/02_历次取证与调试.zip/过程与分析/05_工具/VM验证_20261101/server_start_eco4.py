from pathlib import Path
import os,subprocess,json,shutil
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_fixes_20261101';r=h/'kwt_versions_20261101/v2'
# Script is our own uploaded source, never copied out of the public directory.
script=w/'cap_eco4.tcl';assert script.exists()
job='''from pathlib import Path
import json,os,subprocess,shutil,re
h=Path('/storage2/2026contest/server5/s5_10usr');w=h/'kwt_fixes_20261101';r=h/'kwt_versions_20261101/v2'
libs=json.loads((r.parent/'library_selection.json').read_text());rows=[]
for v in ['v2']:
 for top in ['kwt_nice_core']:
  out=r/'build'/(v+'_eco4')/('synth_'+top);out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
  env=os.environ.copy();env.update({'KWT_ROOT':str(r),'KWT_TOP':top,'KWT_STD_DB':libs['standard']['ss'],'KWT_MIN_STD_DB':libs['standard']['ff'],'KWT_SRAM_DBS':'|'.join(libs['sram']['ss']),'KWT_MIN_SRAM_DBS':'|'.join(libs['sram']['ff']),'KWT_DDC':str(r/'build'/(v+'_reset')/('synth_'+top)/'mapped.ddc'),'KWT_PERIOD':'6.666667','KWT_OUTPUT_CAP':'0.002852'})
  for k in ['TMP','TEMP','TMPDIR']:env[k]=str(out/'tmp')
  with (out/'dc.log').open('w') as f:p=subprocess.run(['dc_shell','-f',str(w/'cap_eco4.tcl')],cwd=str(out),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
  s=(out/'dc.log').read_text();ok=p.returncode==0 and 'ECO_REPAIR_COMPLETE '+top in s and not re.search(r'^Error:',s,re.M)
  rows.append({'v':v,'top':top,'ok':ok});print('DRC',v,top,ok,flush=True)
  if not ok:raise RuntimeError(s[-2000:])
 shutil.copytree(str(r/'build/v2_reset/synth_kwt_dot64'),str(r/'build/v2_eco4/synth_kwt_dot64'))
 rtl=h/'kwt_eda_tmp_20261101/project' if v=='v1' else r
 p=subprocess.run(['make','sta','gate','summary','TAG='+v+'_eco4','RTL_ROOT='+str(rtl)],cwd=str(r/'server_eda'))
 rows.append({'v':v,'checks_exit':p.returncode})
 if p.returncode:raise RuntimeError('checks failed')
(w/'eco4_exit.json').write_text(json.dumps(rows,indent=2))
'''
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
with (w/'eco4_job.log').open('w') as f:p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('ECO_JOB_PID',p.pid)
