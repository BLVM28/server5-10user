from pathlib import Path
import json,os,subprocess,re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_fixes_20261101';r=h/'kwt_versions_20261101/v2';libs=json.loads((r.parent/'library_selection.json').read_text())
print('CRITICAL DELAY CELLS')
s=(r/'build/v2_eco2/sta_kwt_nice_core_ss/setup.rpt').read_text()
for line in s.splitlines():
 if 'Startpoint:' in line or 'Endpoint:' in line or '(DEL' in line or 'slack (' in line:print(line)
t='''set_app_var link_library [concat [list * $env(STD)] [split $env(RAMS) |]]
read_ddc $env(DDC)
current_design kwt_nice_core
link
foreach_in_collection c [get_lib_cells */DEL*] {
 foreach_in_collection p [filter_collection [get_lib_pins -of_objects $c] "direction == out"] {
  puts "DELAYCELL [get_object_name $c] FUNCTION [get_attribute $p function]"
 }
}
exit
'''
(w/'delay_query.tcl').write_text(t);env=os.environ.copy();env.update(STD=libs['standard']['ss'],RAMS='|'.join(libs['sram']['ss']),DDC=str(r/'build/v2_eco2/synth_kwt_nice_core/mapped.ddc'))
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
with (w/'delay_query.log').open('w') as f:p=subprocess.run(['dc_shell','-f',str(w/'delay_query.tcl')],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT)
for s in (w/'delay_query.log').read_text().splitlines():
 if s.startswith(('DELAYCELL','Error:')):print(s)
