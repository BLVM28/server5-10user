from pathlib import Path
import json,re,hashlib
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
r=h/'kwt_versions_20261101/v2';w=h/'kwt_fixes_20261101'
for tag in ['v1_reset','v2_eco5']:
 b=r/'build'/tag;f=b/'full_gate_result.json'
 print('VERSION',tag)
 if f.exists():
  x=json.loads(f.read_text());print('FULL_GATE',x.get('completed'),x.get('error'),x.get('stages'))
  print('NETLIST_SHA',x.get('netlist_sha256'),'SDF_SHA',x.get('sdf_sha256'))
 for f in [w/(tag+'_full_gate.log'),b/'full_gate/run.log']:
  if f.exists():print(f.name, f.read_text(errors='replace')[-500:])
 for corner in ['ss','ff']:
  d=b/('sta_kwt_nice_core_'+corner)
  print(corner,(d/'metrics.txt').read_text().strip())
  print('DRC_COUNT',sum('VIOLATED' in x for x in (d/'violations.rpt').read_text().splitlines()))
  print('COVERAGE', (d/'coverage.rpt').read_text()[-1500:])
