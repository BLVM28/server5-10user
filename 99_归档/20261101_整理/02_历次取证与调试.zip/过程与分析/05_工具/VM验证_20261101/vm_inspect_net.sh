set -eu
cd /home/eda/kwt_vm_20261101
source flow/env.sh
python3 - <<'PY' > evidence/net_inspect.txt
from pathlib import Path
import re,json
r=Path('/home/eda/kwt_vm_20261101')
for v in ['v1','v2']:
 s=(r/'results'/v/'synth_dot/mapped.v').read_text()
 print(v,'HEADER',s[:3000])
 print('CELLS',sorted(set(re.findall(r'^\s*(\w+)\s+\S+\s*\(',s,re.M))))
 if v=='v2':
  for n in ['g4879__9315','g4878__6161']:
   m=re.search(r'^.*\b'+n+r'\s*\([\s\S]*?;',s,re.M);print(m.group(0) if m else n+' missing')
 for c in ['slow','fast']:
  p=r/'results'/v/('sta_'+c)
  for n in ['hold.rpt','constraints.rpt','drv.rpt']:
   if (p/n).exists():print(v,c,n,(p/n).read_text()[:12000])
PY
