from pathlib import Path
import os,subprocess,shutil
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';env=os.environ.copy();env['TMPDIR']=str(w/'tmp')
lc=Path(shutil.which('lc_shell')).resolve().parent.parent
env['SYNOPSYS_LC_ROOT']=str(lc);print('LC_ROOT',str(lc))
with (w/'probe_pt_lc_env.log').open('w') as f:
 subprocess.run(['pt_shell','-x','exit'],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT)
s=(w/'probe_pt_lc_env.log').read_text();print(s[-2200:])
if 'Error:' not in s:
 p=w/'project/server_eda/run_checks.py';s=p.read_text()
 old="if extra:env.update(extra)"
 new="if shutil.which('lc_shell'):env['SYNOPSYS_LC_ROOT']=str(Path(shutil.which('lc_shell')).resolve().parent.parent)\n        if extra:env.update(extra)"
 assert old in s;p.write_text(s.replace(old,new))
 with (w/'make_resume3.log').open('w') as f:
  p=subprocess.Popen(['make','sta','gate','summary'],cwd=str(w/'project/server_eda'),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print('RESUMED',p.pid)
