from pathlib import Path,PurePosixPath
import hashlib,json,zipfile,shutil
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';src=h/'Desktop/kwt_eda_upload_20261101/kwt_rtl_v1.zip'
sha=hashlib.sha256(src.read_bytes()).hexdigest()
assert sha=='327edf5c22e8a92b388195178e315a379d8a9998d6c7df4d643ec038d1d7fff9'
shutil.copy2(str(src),str(w/'kwt_rtl_v1.zip'))
dest=w/'project';dest.mkdir(exist_ok=True)
assert dest.resolve().parent==w.resolve()
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts
  target=dest.joinpath(*p.parts).resolve();assert str(target).startswith(str(dest.resolve())+'/')
 z.extractall(str(dest))
 manifest=json.loads(z.read('MANIFEST.json'))
 for n,digest in manifest['sha256'].items():assert hashlib.sha256((dest/n).read_bytes()).hexdigest()==digest,n
record={'zip_sha256':sha,'files_verified':len(manifest['sha256']),'path':str(dest)}
(w/'upload_verified.json').write_text(json.dumps(record,indent=2))
print('UPLOAD_VERIFIED',json.dumps(record))
