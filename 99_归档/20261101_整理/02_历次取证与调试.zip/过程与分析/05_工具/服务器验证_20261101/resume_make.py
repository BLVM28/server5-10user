from pathlib import Path,PurePosixPath
import zipfile,os,subprocess,json,hashlib
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';project=w/'project'
src=h/'Desktop/kwt_eda_upload_20261101/server_eda_harness_r2.zip'
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='server_eda' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(project))
print('HARNESS_SHA256',hashlib.sha256(src.read_bytes()).hexdigest())
print('LIBRARY_COMPILE_TAIL',(w/'compile_sram.log').read_text()[-1500:])
libs=json.loads((w/'library_selection.json').read_text())
for key in ['ss','tt','ff']:
 print('DB_CHECK',key,[(Path(p).name,Path(p).exists()) for p in libs['sram'][key]])
env=os.environ.copy()
for k in ['TMPDIR','TMP','TEMP']:env[k]=str(w/'tmp')
with (w/'make_resume.log').open('w') as log:
 p=subprocess.Popen(['make','sta','gate','summary'],cwd=str(project/'server_eda'),env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print('MAKE_PID',p.pid)
