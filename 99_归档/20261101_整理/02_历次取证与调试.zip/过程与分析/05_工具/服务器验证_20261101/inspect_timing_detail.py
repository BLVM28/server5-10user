from pathlib import Path
import re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
b=h/'kwt_eda_tmp_20261101/project/build/server_eda'
for p in sorted(b.glob('sta_*')):
 print('DESIGN',p.name)
 for n in ['topology.txt','check_timing.rpt','reg_setup.rpt','data_hold.rpt','coverage.rpt','disabled_arcs.rpt']:
  s=(p/n).read_text();lines=s.splitlines()
  if n=='topology.txt':print(s.strip())
  elif n=='check_timing.rpt':print('CHECK_TIMING',s.strip().splitlines()[-2:])
  elif n.endswith('hold.rpt') or n.endswith('setup.rpt'):
   print(n,*[x.strip() for x in lines if re.search('Startpoint:|Endpoint:|slack ',x)][:3])
  elif n=='coverage.rpt':print('COVERAGE',*[x.strip() for x in lines if re.search('setup|hold|recovery|removal|All Checks',x)])
  else:print('DISABLED_ARCS',*[x.strip() for x in lines if re.search('user|constant|loop|^Total|core/',x)][:6])
