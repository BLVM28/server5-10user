from pathlib import Path
import sys,os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';p=w/'project/server_eda/run_checks.py'
s=p.read_text();s=s.replace('str(time.time_ns())','str(int(time.time()*1000000))');p.write_text(s)
print('PYTHON',sys.version);print((w/'make_resume.log').read_text()[-4000:])
if 'time_ns' in (w/'make_resume.log').read_text() and 'Error' in (w/'make_resume.log').read_text():
 env=os.environ.copy();env['TMPDIR']=str(w/'tmp')
 with (w/'make_resume2.log').open('w') as log:
  p=subprocess.Popen(['make','sta','gate','summary'],cwd=str(w/'project/server_eda'),env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print('RESUME_PID',p.pid)
