from pathlib import Path
import re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
b=h/'kwt_eda_tmp_20261101/project/build/server_eda'
p=b/'sta_kwt_dot64_ss'
for name in ['pt.log','units.rpt','check_timing.rpt']:
 s=(p/name).read_text(errors='replace')
 print('FILE',name)
 if name=='pt.log':
  for line in s.splitlines():
   if re.search(r'Error:|Warning:|CONSTRAINT_OUTPUT',line): print(line)
 else:print(s[:1600])
