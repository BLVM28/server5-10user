from pathlib import Path
import os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';b=w/'project/build/server_eda'
s=(b/'sta_kwt_dot64_ss/pt.log').read_text();lines=s.splitlines()
for i,line in enumerate(lines):
 if 'PT-063' in line:print('\n'.join(lines[max(0,i-8):i+9]))
env=os.environ.copy();env['TMPDIR']=str(w/'tmp')
p=w/'probe_pt_lc.tcl';p.write_text('printvar *lc*\nhelp *lc*\nexit\n')
with (w/'probe_pt_lc.log').open('w') as f:
 subprocess.run(['pt_shell','-f',str(p)],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT)
for line in (w/'probe_pt_lc.log').read_text().splitlines():
 if 'lc' in line.lower() or 'PT-063' in line:print(line)
