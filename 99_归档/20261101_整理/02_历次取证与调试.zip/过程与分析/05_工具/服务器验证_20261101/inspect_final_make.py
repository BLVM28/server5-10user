from pathlib import Path
import re,json,zipfile,hashlib
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';b=w/'project/build/server_eda'
print('MAKE_PROGRESS')
for s in (w/'make_all_final.log').read_text().splitlines():
 if s.startswith(('python3','regression','compile ','run ','dc ','pt ','make:','TIMING_')):print(s)
for n in ['synth_kwt_dot64/dc.log','synth_kwt_nice_core/dc.log','sta_kwt_nice_core_ss/pt.log']:
 s=(b/n).read_text();print('VERSION',n,*[l.strip() for l in s.splitlines() if re.search(r'Version [A-Z]-',l)][:1])
for p in sorted(b.glob('*_result.json')):
 d=json.loads(p.read_text());print('RESULT',p.stem,d.get('completed'),d.get('timing_slack_met',''))
 if not d.get('completed'):print(d.get('error','')[-1000:])
z=zipfile.ZipFile(str(w/'kwt_rtl_v1.zip'));project=w/'project'
fs=list((project/'rtl').glob('*.sv'))+[project/'integration/e203_subsys_nice_core.v']
assert all(f.read_bytes()==z.read(f.relative_to(project).as_posix()) for f in fs)
print('ORIGINAL_RTL_MATCH',len(fs))
p=b/'sta_kwt_nice_core_ss/untested.rpt'
if p.exists():
 s=p.read_text();print('UNTESTED_HEAD');print('\n'.join(s.splitlines()[:29]))
