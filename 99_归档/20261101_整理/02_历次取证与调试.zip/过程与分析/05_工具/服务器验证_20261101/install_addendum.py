from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,shutil
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';project=w/'project'
src=h/'Desktop/kwt_eda_upload_20261101/kwt_server_eda_addendum_20261101.zip'
digest=hashlib.sha256(src.read_bytes()).hexdigest()
assert digest=='9dd59ecb77c3e781c1030de36aae2360e659aab4941e23a5ec447b98607fed66'
with zipfile.ZipFile(str(src)) as z:
 m=json.loads(z.read('MANIFEST_EDA.json'))
 assert set(z.namelist())==set(m['sha256'])|{'MANIFEST_EDA.json'}
 for n in z.namelist():
  p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts
  dst=project/n;assert str(dst.resolve()).startswith(str(project.resolve())+'/')
  if n.startswith('server_eda/') and not n.endswith('.md'):
   assert dst.read_bytes()==z.read(n),'Tested harness changed: '+n
  if n in m['sha256']:assert hashlib.sha256(z.read(n)).hexdigest()==m['sha256'][n]
  if dst.exists() and dst.read_bytes()!=z.read(n):
   old=w/'before_final_addendum'/n;old.parent.mkdir(parents=True,exist_ok=True)
   assert not old.exists();shutil.copy2(str(dst),str(old))
 z.extractall(str(project))
 for n,d in m['sha256'].items():assert hashlib.sha256((project/n).read_bytes()).hexdigest()==d
shutil.copy2(str(src),str(w/src.name))
record={'zip_sha256':digest,'files_verified':len(m['sha256']),'tested_harness_unchanged':True,'project':str(project)}
(w/'eda_addendum_verified.json').write_text(json.dumps(record,indent=2))
print('FINAL_DELIVERY_VERIFIED',json.dumps(record))
b=project/'build/server_eda'
for n in ['functional','activation','sram150','dot150','synth','sta','gate']:
 d=json.loads((b/(n+'_result.json')).read_text());assert d['completed'];print('COMPLETE',n)
print('TIMING_SLACK_MET',json.loads((b/'sta_result.json').read_text())['timing_slack_met'])
print('REPORT',project/'server_eda/RESULTS.md')
print('ALL_GENERATED_ARTIFACTS_RETAINED_IN_PERSONAL_HOME')
