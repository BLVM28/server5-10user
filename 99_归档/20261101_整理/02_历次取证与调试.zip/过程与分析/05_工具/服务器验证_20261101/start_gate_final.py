from pathlib import Path,PurePosixPath
import zipfile,os,subprocess,hashlib
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';project=w/'project'
src=h/'Desktop/kwt_eda_upload_20261101/server_eda_harness_r4.zip'
assert hashlib.sha256(src.read_bytes()).hexdigest()=='8dba90fc48e1cfe4df09ad96a8a08eab6a5a82d0b972498605341642ba630536'
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='server_eda' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(project))
env=os.environ.copy()
for k in ['TMPDIR','TMP','TEMP']:env[k]=str(w/'tmp')
with (w/'make_gate_final.log').open('w') as f:
 p=subprocess.Popen(['make','dot150','gate','summary'],cwd=str(project/'server_eda'),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('MAKE_PID',p.pid)
