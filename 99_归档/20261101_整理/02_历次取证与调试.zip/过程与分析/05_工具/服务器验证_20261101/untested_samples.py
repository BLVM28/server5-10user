from pathlib import Path
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
p=h/'kwt_eda_tmp_20261101/project/build/server_eda/sta_kwt_nice_core_ss/untested.rpt';lines=p.read_text().splitlines()
for reason in ['no_clock','constant_disabled']:
 print('REASON',reason);count=0
 for i,line in enumerate(lines):
  if 'untested' in line and reason in line:
   print('\n'.join(lines[max(0,i-3):i+1]));count+=1
   if count==3:break
