from pathlib import Path
import re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';b=w/'project/build/server_eda'
print('GATE_MAKE');print((w/'make_gate_r1.log').read_text()[-1800:])
for name in ['compile.log','run.log','sdf_annotation.log']:
 p=b/'gate'/name
 if p.exists():
  print('GATE_FILE',name)
  lines=p.read_text(errors='replace').splitlines()
  if name=='compile.log':print('\n'.join(s for s in lines if 'Error' in s or 'Warning' in s)[:500])
  else:print('\n'.join(lines[-18:]))
for p in sorted(b.glob('sta_*/pt.log')):
 print('PT_ISSUES',p.parent.name,[s for s in p.read_text().splitlines() if s.startswith(('Error:','Warning:'))])
