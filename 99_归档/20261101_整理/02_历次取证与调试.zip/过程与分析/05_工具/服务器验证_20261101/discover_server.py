from pathlib import Path
import os,shutil,subprocess
home=Path('/storage2/2026contest/server5/s5_10usr')
assert Path.cwd().resolve()==home.resolve()
work=home/'kwt_eda_tmp_20261101'
work.mkdir(exist_ok=True)
assert work.resolve().parent==home.resolve()
(work/'tmp').mkdir(exist_ok=True)
print('WORK',work)
for name in ['vcs','dc_shell','pt_shell','genus','xrun','make','python3','curl','wget']:
 print('TOOL',name,shutil.which(name))
pub=Path('/storage1/admin_public_dir')
for folder in [pub/'SMIC40_2025',pub/'SRAM_Lib_2025/RAMSP128X16',pub/'SRAM_Lib_2025/RAMSP1024X16']:
 print('DIRECTORY',folder)
 for p in sorted(folder.iterdir()):print('ENTRY',p.name,'DIR' if p.is_dir() else p.stat().st_size)
print('INITIAL_DESKTOP',*[p.name for p in (home/'Desktop').iterdir()][:15],sep='\n')
