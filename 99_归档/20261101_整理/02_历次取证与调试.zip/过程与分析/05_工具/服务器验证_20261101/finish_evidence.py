from pathlib import Path
import json,re,hashlib
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';b=w/'project/build/server_eda'
print('FINAL_MAKE_TAIL');print((w/'make_all_final.log').read_text()[-2000:])
for n in ['functional','activation','sram150','dot150','synth','sta','gate']:
 d=json.loads((b/(n+'_result.json')).read_text());print('FINAL',n,d['completed'],d.get('timing_slack_met',''))
 if n in ['functional','activation']:
  for p in (w/'project/build'/('server_'+n)).glob('*.log'):
   for line in p.read_text(errors='replace').splitlines():
    if line.startswith('ALL PASS'):print(p.name,line)
 if n in ['sram150','dot150','gate']:
  for line in (b/n/'run.log').read_text(errors='replace').splitlines():
   if line.startswith('ALL PASS'):print(line)
p=b/'gate/mapped.sdf';s=p.read_text();print('SDF',hashlib.sha256(p.read_bytes()).hexdigest(),'IOPATH',s.count('(IOPATH'),'INTERCONNECT',s.count('(INTERCONNECT'),'TIMINGCHECK',s.count('(TIMINGCHECK'))
print('ANNOTATION_COUNTS',re.findall(r'Total (?:errors|warnings):\s*\d+',(b/'gate/sdf_annotation.log').read_text()))
