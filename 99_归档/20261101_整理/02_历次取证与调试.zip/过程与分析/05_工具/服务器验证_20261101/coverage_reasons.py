from pathlib import Path
import re,collections
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
b=h/'kwt_eda_tmp_20261101/project/build/server_eda';p=b/'sta_kwt_nice_core_ss'
print('UNTESTED_SAMPLE');print('\n'.join((p/'untested.rpt').read_text().splitlines()[:37]))
print('DISABLED_REASON_COUNTS')
print(collections.Counter(re.findall(r'^\s+([a-zA-Z])\s+(.+)$',(p/'disabled_arcs.rpt').read_text(),re.M)).most_common(12))
print('SYNTH_ERRORS',[(d.parent.name,[s for s in d.read_text().splitlines() if s.startswith(('Error:','Warning:'))][:5]) for d in b.glob('synth_*/check_design.rpt')])
