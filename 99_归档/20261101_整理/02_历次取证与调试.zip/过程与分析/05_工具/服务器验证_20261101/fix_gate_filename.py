from pathlib import Path
import os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';p=w/'project/server_eda/tb_dot64_gate.sv'
s=p.read_text();old='integer n,k,checks=0;string dir,sdf;';assert old in s
p.write_text(s.replace(old,'integer n,k,checks=0;string dir;\n  reg [8191:0] sdf;'))
env=os.environ.copy();env['TMPDIR']=str(w/'tmp')
with (w/'make_gate_r1.log').open('w') as f:
 p=subprocess.Popen(['make','gate','summary'],cwd=str(w/'project/server_eda'),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('GATE_PID',p.pid)
