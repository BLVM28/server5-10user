from pathlib import Path
import json,re,os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';lib=w/'libraries'
standard={k:lib/('scc40nll_vhsc40_hvt_'+name+'_basic.db') for k,name in {
 'ss':'ss_v0p99_125c','tt':'tt_v1p1_25c','ff':'ff_v1p21_-40c'}.items()}
assert all(p.exists() for p in standard.values()),list(lib.iterdir())
verilog=lib/'scc40nll_vhsc40_hvt.v';assert verilog.exists()
print('STD_MODULES',*[s for s in re.findall(r'(?m)^module\s+(\w+)',verilog.read_text()) if 'INV' in s][:8])
commands=[];sram={};sources={}
for corner,suffix in {'ss':'ss_0p99v_0p99v_125c','tt':'tt_1p10v_1p10v_25c','ff':'ff_1p21v_1p21v_m40c'}.items():
 sram[corner]=[];sources[corner]=[]
 for cell in ['RAMSP128X16','RAMSP1024X16']:
  p=Path('/storage1/admin_public_dir/SRAM_Lib_2025')/cell/'lib'/(cell+'_'+suffix+'.lib')
  assert p.exists(),p
  text=p.read_text();name=re.search(r'\blibrary\s*\(\s*"?([^"\s)]+)',text).group(1)
  dest=lib/(name+'.db');sram[corner].append(str(dest));sources[corner].append(str(p))
  commands+=['read_lib {'+str(p)+'}', 'write_lib {'+name+'} -format db -output {'+str(dest)+'}']
commands+=['puts "LIBRARY_COMPILE_FINISHED"','exit']
(w/'compile_sram.tcl').write_text('\n'.join(commands)+'\n')
config={'standard':{k:str(p) for k,p in standard.items()},'sram':sram,
 'standard_verilog':str(verilog),'sram_lib_sources':sources,
 'qualification':'Pre-layout HVT SMIC40 library; SS setup / FF min analysis, not complete signoff'}
(w/'library_selection.json').write_text(json.dumps(config,indent=2))
env=os.environ.copy()
for k in ['TMPDIR','TMP','TEMP']:env[k]=str(w/'tmp')
with (w/'compile_sram.log').open('w') as log:
 p=subprocess.Popen(['lc_shell','-f',str(w/'compile_sram.tcl')],cwd=str(w),env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print('LIBRARY_COMPILER_PID',p.pid)
print('SELECTED',json.dumps(config['standard']))
