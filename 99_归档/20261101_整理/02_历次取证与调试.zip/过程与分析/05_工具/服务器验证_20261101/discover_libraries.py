from pathlib import Path
import os,json,tarfile
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
pub=Path('/storage1/admin_public_dir')
paths=[]
for root,dirs,files in os.walk(str(pub),followlinks=False):
 dirs[:]=[d for d in dirs if not Path(root,d).is_symlink()]
 for f in files:
  if f.endswith(('.db','.lib','.tcl','.tar','.gz','.zip')):paths.append(str(Path(root,f)))
(h/'kwt_eda_tmp_20261101/library_inventory.json').write_text(json.dumps(paths,indent=2))
print('NON_SRAM_CANDIDATES')
print(*[p for p in paths if '/SRAM_Lib_2025/' not in p][:35],sep='\n')
print('SRAM_DB_TT',*[p for p in paths if '/db/' in p and 'tt' in p and ('RAMSP1024X16/' in p or 'RAMSP128X16/' in p)][:6],sep='\n')
