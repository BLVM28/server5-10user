from pathlib import Path
import os,subprocess,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';project=w/'project';assert (w/'upload_verified.json').exists()
env=os.environ.copy()
for k in ['TMPDIR','TEMP','TMP']:env[k]=str(w/'tmp')
code="""from pathlib import Path
import subprocess,json,os
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_eda_tmp_20261101');p=w/'project'
base=['python3',str(p/'py/run_linux.py'),'--sim','vcs','--foundry','/storage1/admin_public_dir/SRAM_Lib_2025']
runs=[('server_functional',[]),('server_activation',['--tops','tb_kwt_system','--vectors',str(p/'vec/activation_smoke/rtl')])]
results=[]
for tag,extra in runs:
 print('START',tag,flush=True)
 r=subprocess.run(base+['--tag',tag]+extra,cwd=str(p))
 results.append({'tag':tag,'exit':r.returncode});print('FINISH',tag,r.returncode,flush=True)
(w/'functional_runs.json').write_text(json.dumps(results,indent=2))
"""
(w/'run_functional.py').write_text(code)
with (w/'functional.log').open('w') as log:
 p=subprocess.Popen(['python3','-u',str(w/'run_functional.py')],cwd=str(w),env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print('FUNCTIONAL_PID',p.pid)
scan="""import tarfile,json,hashlib,time
from pathlib import Path
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_eda_tmp_20261101');out=w/'libraries';out.mkdir(exist_ok=True)
items=[];saved=[];start=time.monotonic()
with tarfile.open('/storage1/admin_public_dir/SMIC40_2025/S40.tar.gz','r|gz') as t:
 for i,m in enumerate(t):
  if i%1000==0:print('PROGRESS',i,m.name,round(time.monotonic()-start,1),flush=True)
  if m.isfile() and m.name.lower().endswith(('.db','.db.gz','.lib','.lib.gz','.v','.v.gz')):
   print('CANDIDATE',i,m.name,m.size,flush=True);items.append({'name':m.name,'size':m.size})
   if '/SCC40NLL_VHSC40_HVT_V0.1/' in m.name and m.size<100000000:
    target=out/Path(m.name).name
    data=t.extractfile(m).read();target.write_bytes(data)
    saved.append({'source':m.name,'file':str(target),'sha256':hashlib.sha256(data).hexdigest()})
  if i%1000==0:(w/'timing_library_scan.json').write_text(json.dumps({'items':items,'saved':saved},indent=2))
  if saved and '/SCC40NLL_VHSC40_HVT_V0.1/' not in m.name and m.name!='S40/smic/':break
(w/'timing_library_scan.json').write_text(json.dumps({'items':items,'saved':saved},indent=2))
print('LIB_SCAN_COMPLETE',len(items),len(saved),round(time.monotonic()-start,1),flush=True)
"""
(w/'scan_timing_libraries.py').write_text(scan)
with (w/'scan_timing_libraries.log').open('w') as log:
 p=subprocess.Popen(['python3','-u',str(w/'scan_timing_libraries.py')],cwd=str(w),env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print('LIBRARY_SCAN_PID',p.pid)
