from pathlib import Path
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101'
for n in ['functional.log','scan_timing_libraries.log']:
 print('LOG',n);print((w/n).read_text()[-4500:])
