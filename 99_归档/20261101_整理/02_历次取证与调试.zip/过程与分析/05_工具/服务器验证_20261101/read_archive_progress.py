from pathlib import Path
import shutil
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101'
print('LIB_COMPILER',shutil.which('lc_shell'))
print((w/'scan_archive.log').read_text()[-6500:])
print('UPLOAD',[(p.name,p.stat().st_size) for p in (h/'Desktop/kwt_eda_upload_20261101').glob('*')])
