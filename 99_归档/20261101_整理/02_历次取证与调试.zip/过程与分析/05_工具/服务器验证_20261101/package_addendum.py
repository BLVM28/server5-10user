"""Package only our addendum, without public server libraries or tool logs."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[3]/'v1'
files=[p for p in sorted((root/'server_eda').iterdir()) if p.is_file()]
files += [root/'README.md',root/'validation.md',root/'build/server_eda_observed.json']
manifest={
 'description':'Own EDA test harness and observed results; apply alongside original RTL package',
 'date':'2026-11-01',
 'original_zip_sha256':'327edf5c22e8a92b388195178e315a379d8a9998d6c7df4d643ec038d1d7fff9',
 'sha256':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
mp=root/'MANIFEST_EDA.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
out=root/'dist/kwt_server_eda_addendum_20261101.zip'
assert not out.exists(),'Preserve delivered packages; select a new revision name'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[mp]:z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(out) as z:
 for n,digest in manifest['sha256'].items():assert hashlib.sha256(z.read(n)).hexdigest()==digest,n
digest=hashlib.sha256(out.read_bytes()).hexdigest()
out.with_suffix(out.suffix+'.sha256').write_text(digest+'  '+out.name+'\n',encoding='ascii')
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'files_verified':len(files),'sha256':digest}))
