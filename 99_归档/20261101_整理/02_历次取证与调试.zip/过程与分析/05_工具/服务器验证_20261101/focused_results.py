from pathlib import Path
import json,re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';b=w/'project/build/server_eda'
print('MAKE', (w/'make_final_checks.log').read_text()[-900:])
for p in sorted(b.glob('*_result.json')):
 d=json.loads(p.read_text());print('RESULT',p.stem,d.get('completed'))
for name in ['run.log','sdf_annotation.log']:
 p=b/'gate'/name
 if p.exists():
  print('GATE',name);print('\n'.join(p.read_text(errors='replace').splitlines()[-15:]))
for p in sorted(b.glob('sta_*/metrics.txt')):
 print(p.parent.name,p.read_text().strip())
