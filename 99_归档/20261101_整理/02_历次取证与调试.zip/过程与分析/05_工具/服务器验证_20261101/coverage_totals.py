from pathlib import Path
import re,collections
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
b=h/'kwt_eda_tmp_20261101/project/build/server_eda'
for p in sorted(b.glob('sta_*')):
 if not p.is_dir():continue
 print(p.name)
 s=(p/'untested.rpt').read_text();print('UNTESTED_REASONS',collections.Counter(re.findall(r'untested\s+([a-z_]+)',s)))
 print('CHECK_TIMING',(p/'check_timing.rpt').read_text().strip().splitlines()[-2:])
 print('METRICS',(p/'metrics.txt').read_text().strip())
for p in sorted(b.glob('synth_*/check_design.rpt')):
 print('CHECK_DESIGN',p.parent.name,'ERRORS',len(re.findall(r'^Error:',p.read_text(),re.M)))
