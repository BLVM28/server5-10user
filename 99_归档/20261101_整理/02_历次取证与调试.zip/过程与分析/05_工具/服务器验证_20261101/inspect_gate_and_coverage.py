from pathlib import Path
import re,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';b=w/'project/build/server_eda'
d=json.loads((b/'gate_result.json').read_text());print('GATE_COMPLETED',d['completed'])
for n in ['run.log','sdf_annotation.log']:
 s=(b/'gate'/n).read_text(errors='replace');print(n)
 print('\n'.join(s.splitlines()[-13:]))
p=b/'sta_kwt_nice_core_ss'
print('COVERAGE_HEADER');print('\n'.join((p/'coverage.rpt').read_text().splitlines()[10:22]))
print('DISABLED_ARCS');print('\n'.join((p/'disabled_arcs.rpt').read_text().splitlines()[8:28]))
