from pathlib import Path
import json,re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';out=w/'project/build/server_eda'
print('MAKE_STAGES')
for line in (w/'make_all.log').read_text().splitlines():
 if line.startswith(('python3 ','regression_','compile ','run ','dc ','pt ','make:')):print(line)
for p in sorted(out.glob('*_result.json')):
 d=json.loads(p.read_text());print('RESULT',p.stem,d.get('completed'))
 if not d.get('completed'):print('ERROR',d.get('error','')[-1500:])
for p in sorted(out.glob('sta_*/metrics.txt')):print(p.parent.name,p.read_text().strip())
for p in sorted(out.glob('synth_*/area.rpt')):
 print('AREA',p.parent.name,*[s.strip() for s in p.read_text().splitlines() if 'Total cell area:' in s or 'Macro/Black Box area:' in s])
for p in sorted(out.glob('*/run.log')):
 print('SIM',p.parent.name,*re.findall(r'ALL PASS[^\n]*',p.read_text()))
