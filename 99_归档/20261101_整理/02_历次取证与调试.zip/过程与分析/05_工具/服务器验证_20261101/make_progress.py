from pathlib import Path
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101'
print((w/'make_all.log').read_text()[-5500:])
p=w/'project/build/server_eda'
for f in sorted(p.glob('synth_*/dc.log')):
 print('DC_TAIL',f.parent.name);print(f.read_text()[-1400:])
