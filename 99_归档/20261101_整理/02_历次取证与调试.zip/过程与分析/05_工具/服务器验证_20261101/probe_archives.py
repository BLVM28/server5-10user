from pathlib import Path
import os,tarfile,json,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101'
for name in ['RAMSP128X16','RAMSP1024X16']:
 p=Path('/storage1/admin_public_dir/SRAM_Lib_2025')/name
 print('SRAM_DB',name,*[x.name for x in (p/'db').iterdir()][:10],sep='\n')
 print('SRAM_LIB',name,*[x.name for x in (p/'lib').iterdir()][:8],sep='\n')
code="""import tarfile,json,time
from pathlib import Path
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_eda_tmp_20261101')
items=[]
with tarfile.open('/storage1/admin_public_dir/SMIC40_2025/S40.tar.gz','r|gz') as t:
 for i,m in enumerate(t):
  items.append({'name':m.name,'size':m.size,'file':m.isfile()})
  if i<35 or m.name.endswith(('.db','.lib','.db.gz','.lib.gz')):print(i,m.name,m.size,flush=True)
  if (i+1)%100==0:(w/'archive_head.json').write_text(json.dumps(items,indent=2))
  if i>=999 or sum(x['name'].endswith('.db') for x in items)>=12:break
(w/'archive_head.json').write_text(json.dumps(items,indent=2))
print('SCAN_COMPLETE',len(items),flush=True)
"""
(w/'scan_archive.py').write_text(code)
env=os.environ.copy();env['TMPDIR']=str(w/'tmp')
with (w/'scan_archive.log').open('w') as log:
 p=subprocess.Popen(['python3','-u',str(w/'scan_archive.py')],cwd=str(w),env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print('SCAN_PID',p.pid)
