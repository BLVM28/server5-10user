from pathlib import Path,PurePosixPath
import zipfile,os,subprocess,hashlib
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_eda_tmp_20261101';project=w/'project'
src=h/'Desktop/kwt_eda_upload_20261101/server_eda_harness_r5.zip'
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='server_eda' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(project))
print('UPLOADED_HARNESS_SHA',hashlib.sha256(src.read_bytes()).hexdigest())
env=os.environ.copy()
for k in ['TMPDIR','TMP','TEMP']:env[k]=str(w/'tmp')
with (w/'make_all_final.log').open('w') as f:
 p=subprocess.Popen(['make','all'],cwd=str(project/'server_eda'),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('MAKE_ALL_PID',p.pid)
