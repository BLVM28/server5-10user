from pathlib import Path
r=Path(__file__).resolve().parents[3]/'v2'
s=(r/'tb/tb_kwt_system.sv').read_text(encoding='utf-8')
s=s.replace('module tb_kwt_system;','module tb_core_gate;').replace('always #5 nice_clk','always #(6.666667/2.0) nice_clk')
s=s.replace('kwt_nice_core #(.MEM_BASE(BASE),.MEM_BYTES(BYTES),.W_BANK_AW(WAW),.PACK_LOW_FIRST(PACK)) dut(.*);','kwt_nice_core dut(.*);')
a=s.index('      if(dut.core.x_rv');b=s.index('\n    end\n  end',a);s=s[:a]+s[b:]
a=s.index('  always @(posedge nice_clk');b=s.index('\n  task reset_all',a)
s=s[:a]+s[a:b].replace('<=','<=#1.000 ')+s[b:]
s=s.replace('@(negedge nice_clk);','@(posedge nice_clk);#1.000;')
s=s.replace(' || mac_outputs-start_mac!=25344','').replace('check_mac=1;','check_mac=0;')
s=s.replace('      if(dut.c_sat!==sat_expect[layer])$fatal(1,"saturation count mismatch");\n','')
s=s.replace('$display("matrix layer %0d PASS core_cycles=%0d writes=%0d",layer,dut.c_cycles,write_acks-start_writes);','$display("matrix gate layer %0d PASS writes=%0d transactions=%0d",layer,write_acks-start_writes,transactions-start_transactions);')
a=s.index('  task abort_stage');b=s.index('  initial begin #200000000',a)
s=s[:a]+'''  initial begin
    $sdf_annotate("mapped.sdf",dut,,"sdf_annotation.log","MAXIMUM");
    if(!$value$plusargs("VEC_DIR=%s",dir))$fatal(1,"VEC_DIR required");
    reset_all();full_case(0,1);
    $display("ALL PASS, %0d/1 full-core SDF matrix",tests);$finish;
  end
'''+s[b:]
assert 'dut.' not in s
(r/'server_eda/tb_core_gate.sv').write_text(s,encoding='utf-8')
