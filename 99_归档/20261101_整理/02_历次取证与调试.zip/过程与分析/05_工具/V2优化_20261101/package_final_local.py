from pathlib import Path
import hashlib,json,zipfile
w=Path(__file__).resolve().parents[3];r=w/'v2';out=w/'releases/20261101_v2/v2.zip';assert not out.exists()
old=json.loads((out.parent/'v1_package.json').read_text());assert hashlib.sha256((out.parent/'v1.zip').read_bytes()).hexdigest()==old['sha256']
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(r)
 if any(x in ['dist','__pycache__','xsim.dir','.Xil'] for x in rel.parts):continue
 if p.name in ['MANIFEST.json','MANIFEST_EDA.json','RELEASE_MANIFEST.json']:continue
 if rel.parts[0]=='build' and p.suffix not in ['.log','.json','.txt','.f','.tcl']:continue
 files.append(p)
manifest={'version':'v2-local','date':'2026-11-01','scope':'own source, vectors, local simulation logs and manually observed server summary; no downloaded server files','sha256':{p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(r/'RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,'v2/'+p.relative_to(r).as_posix())
 z.write(r/'RELEASE_MANIFEST.json','v2/RELEASE_MANIFEST.json')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n,d in manifest['sha256'].items():assert hashlib.sha256(z.read('v2/'+n)).hexdigest()==d
record={'file':str(out),'files':len(files),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'archive_crc_and_manifest_verified':True}
(out.parent/'v2_package.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record))
