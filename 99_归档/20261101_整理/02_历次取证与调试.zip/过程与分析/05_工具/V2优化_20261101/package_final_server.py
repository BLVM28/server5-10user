from pathlib import Path,PurePosixPath
import zipfile,hashlib,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';r=w/'v2';source=h/'Desktop/kwt_eda_upload_20261101/v2_final.zip'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='bface62133c296d5294ffb98133159ca8a6b2b8272f99b1efde7d9d8e442fbcc'
assert all(x['exit']==0 for x in json.loads((w/'sta_audit_exit.json').read_text()))
assert json.loads((w/'full_gate_exit.json').read_text())['exit']==0
with zipfile.ZipFile(str(source)) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('v2/RELEASE_MANIFEST.json'))['sha256']
 for n,d in manifest.items():
  p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts
  if p.parts[0]=='build':assert p.parts[1] in ['server_observed_v2.json','v2_overlap','v2_overlap_fallback','v2_pipeline','v2_multiplier_exhaustive','v2_swap_fallback']
  assert hashlib.sha256(z.read('v2/'+n)).hexdigest()==d
  if p.parts[0]=='rtl' or n=='integration/e203_subsys_nice_core.v':assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d
 for n in manifest:(r/n).parent.mkdir(parents=True,exist_ok=True);(r/n).write_bytes(z.read('v2/'+n))
 for n,d in manifest.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d
local_record={'upload_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'verified_files':len(manifest),'rtl_was_already_identical_to_tested_source':True}
(w/'v2_final_upload_verified.json').write_text(json.dumps(local_record,indent=2))
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(r)
 if any(x in ['tmp','csrc','work','dist','__pycache__','simv.daidir','xsim.dir','.Xil'] or x.endswith('_sim.daidir') for x in rel.parts):continue
 if p.name in ['MANIFEST.json','MANIFEST_EDA.json','RELEASE_MANIFEST.json']:continue
 if rel.parts[0]=='build' and p.suffix not in ['.log','.rpt','.json','.txt','.v','.sv','.sdf','.sdc','.ddc','.tcl','.f']:continue
 files.append(p)
hashes={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
target=w/'v2.zip';assert not target.exists()
with zipfile.ZipFile(str(target),'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(str(p),'v2/'+p.relative_to(r).as_posix())
 z.writestr('v2/RELEASE_MANIFEST.json',json.dumps({'version':'v2-server','sha256':hashes,'local_source_upload':local_record},indent=2))
with zipfile.ZipFile(str(target)) as z:
 assert z.testzip() is None
 for n,d in hashes.items():assert hashlib.sha256(z.read('v2/'+n)).hexdigest()==d
record={'archive':str(target),'files':len(files),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'archive_and_manifest_verified':True}
(w/'v2_package.json').write_text(json.dumps(record,indent=2))
old=json.loads((w/'v1_package.json').read_text());assert hashlib.sha256((w/'v1.zip').read_bytes()).hexdigest()==old['sha256']
for name,d in [('V1',old),('V2',record)]:
 print(name,'FILES',d['files'],'BYTES',d['bytes']);print(name,'SHA256',d['sha256']);print(name,'SHA_GROUPS',' '.join(d['sha256'][i:i+8] for i in range(0,64,8)))
print('FINAL_UPLOAD_VERIFIED',len(manifest),'FILES; TESTED RTL UNCHANGED; ARCHIVE CRC/MANIFEST VERIFIED')
