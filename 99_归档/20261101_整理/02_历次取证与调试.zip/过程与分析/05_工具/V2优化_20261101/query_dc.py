from pathlib import Path
import os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';w.mkdir(exist_ok=True);(w/'tmp').mkdir(exist_ok=True)
p=w/'dc_help.tcl';p.write_text('help compile\nhelp set_min_library\nhelp set_fix_hold\nexit\n')
env=os.environ.copy()
for k in ['TMPDIR','TEMP','TMP']:env[k]=str(w/'tmp')
with (w/'dc_help.log').open('w') as f:
 subprocess.run(['dc_shell','-f',str(p)],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT)
lines=(w/'dc_help.log').read_text().splitlines()
for i,s in enumerate(lines):
 if any(x in s for x in ['only_hold','incremental','min_library','set_fix_hold','min_version']):print(s)
