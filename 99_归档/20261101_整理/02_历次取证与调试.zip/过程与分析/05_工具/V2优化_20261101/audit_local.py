from pathlib import Path
import zipfile,hashlib,json
ws=Path(__file__).resolve().parents[3]
with zipfile.ZipFile(ws/'releases/20261101_v2/v1.zip') as z:
 m=json.loads(z.read('v1/RELEASE_MANIFEST.json'))['sha256']
 for n,d in m.items():assert hashlib.sha256((ws/'v1'/n).read_bytes()).hexdigest()==d,n
files=[p for p in (ws/'v1/vec').rglob('*') if p.is_file()]
for p in files:assert p.read_bytes()==(ws/'v2/vec'/p.relative_to(ws/'v1/vec')).read_bytes()
changed=[p.name for p in (ws/'v1/rtl').glob('*.sv') if p.read_bytes()!=(ws/'v2/rtl'/p.name).read_bytes()]
print('V1_SNAPSHOT_UNCHANGED',len(m),'VECTORS_IDENTICAL',len(files),'CHANGED_RTL',changed)
