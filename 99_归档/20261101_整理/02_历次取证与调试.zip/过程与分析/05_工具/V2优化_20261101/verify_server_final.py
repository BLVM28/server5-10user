from pathlib import Path
import json,hashlib,re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';r=w/'v2';b=r/'build'
sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'rtl').glob('*.sv')}
for n in ['functional','activation','overlap','pipeline','synth']:
 d=json.loads((b/'v2_150'/(n+'_result.json')).read_text());assert d['completed'];assert {Path(k).name:v for k,v in d['source_sha256'].items()}==sha
for n in ['sram150','dot150']:assert json.loads((b/'v2_150'/(n+'_result.json')).read_text())['completed']
bench=json.loads((b/'benchmark_comparison.json').read_text());assert bench['versions']['v2']['rtl_sha256']==sha
print('FINAL_RTL_MATCHES_SYNTH_AND_REGRESSIONS',len(sha),'RTL_SHA_COMBINED',hashlib.sha256(''.join(sha[k] for k in sorted(sha)).encode()).hexdigest())
for tag in ['v2_reset','v1_reset']:
 d=json.loads((b/tag/'sta_result.json').read_text());print(tag,'completed',d['completed'],'slack_met',d['timing_slack_met'],'constraints_met',d.get('reported_constraints_met'))
 for p in (b/tag).glob('sta_*/violations.rpt'):
  lines=[x.strip() for x in p.read_text().splitlines() if 'VIOLATED' in x]
  if lines:print('VIOLATIONS',tag,p.parent.name,' | '.join(lines))
 for name in ['gate','full_gate']:
  p=b/tag/(name+'_result.json')
  if p.exists():
   print(tag,name,json.loads(p.read_text())['completed']);a=b/tag/name/'sdf_annotation.log';print('SDF',*[x.strip() for x in a.read_text().splitlines() if re.search(r'Total (errors|warnings):',x)])
print('STA_AUDIT_EXIT',(w/'sta_audit_exit.json').read_text() if (w/'sta_audit_exit.json').exists() else 'RUNNING')
print('BENCH_NICE',bench['first_12_layer_nice_cycles']);print('BENCH_CORE',bench['first_12_layer_cycles'])
(w/'final_source_audit.json').write_text(json.dumps({'verified':True,'rtl_sha256':sha,'benchmark_tb_sha256':bench['tb_sha256']},indent=2))
