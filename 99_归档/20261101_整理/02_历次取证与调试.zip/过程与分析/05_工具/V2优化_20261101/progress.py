from pathlib import Path
import re,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';print('STAGES')
for s in (w/'candidate_r1.log').read_text().splitlines():
 if s.startswith(('python3','regression','compile ','run ','dc ','pt ','make:','Error')):print(s)
p=w/'candidate_r1_exit.json'
if p.exists():print('EXIT',p.read_text())
b=w/'v2/build/v2_200'
for p in b.glob('synth_*/dc.log'):
 lines=p.read_text(errors='replace').splitlines();print(p.parent.name)
 print('\n'.join([s for s in lines if s.startswith(('Error:','Warning:'))][-4:]));print('\n'.join(lines[-5:]))
for p in b.glob('sta_*/metrics.txt'):print(p.parent.name,p.read_text().strip())
