from pathlib import Path
import re,json,collections
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';r=w/'v2/build/v2_reset'
for d in sorted(r.glob('sta_*')):
 print('\nSTA',d.name)
 for name in ['check_timing.rpt','coverage.rpt','violations.rpt','topology.txt']:
  p=d/name
  if not p.exists():continue
  s=p.read_text();lines=s.splitlines()
  if name=='check_timing.rpt':lines=[x for x in lines if re.search(r'Warning|no_clock|unconstrained|Error|There are',x)]
  elif name=='coverage.rpt':lines=[x for x in lines if re.search(r'^\s*(setup|hold|recovery|removal|min_pulse_width|Total)',x)]
  elif name=='violations.rpt':lines=[x for x in lines if re.search(r'VIOLATED|slack|No |max_transition|max_capacitance',x)]
  print(name,' | '.join(x.strip() for x in lines))
for d in sorted(r.glob('synth_*')):
 s=(d/'check_design.rpt').read_text();warn=collections.Counter(re.findall(r'\((LINT-\d+)\)',s));print('CHECK_DESIGN',d.name,dict(warn))
 print('EXAMPLES',' | '.join(next((x for x in s.splitlines() if k in x),'') for k in warn))
for n in ['full_gate','baseline_final']:
 p=w/(n+'_exit.json');print('JOB',n,p.read_text() if p.exists() else 'RUNNING');print((w/(n+'.log')).read_text()[-1000:])
