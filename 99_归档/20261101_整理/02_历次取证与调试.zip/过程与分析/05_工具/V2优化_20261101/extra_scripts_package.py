from pathlib import Path
import zipfile,hashlib,json
ws=Path(__file__).resolve().parents[3];root=ws/'v2';out=ws/'releases/20261101_v2/v2_test_additions_r1.zip';assert not out.exists()
names=['server_eda/Makefile','server_eda/run_checks.py','server_eda/benchmark.py','server_eda/binding.py','tb/tb_kwt_mul_pipeline.sv']
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n in names:z.write(root/n,n)
print(json.dumps({'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
