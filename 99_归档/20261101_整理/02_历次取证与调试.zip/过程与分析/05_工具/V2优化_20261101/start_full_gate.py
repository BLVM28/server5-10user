from pathlib import Path,PurePosixPath
import zipfile,os,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';root=w/'v2'
with zipfile.ZipFile(str(h/'Desktop/kwt_eda_upload_20261101/full_gate_r1.zip')) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='server_eda' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(root))
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
job="import subprocess,json\nfrom pathlib import Path\nw=Path("+repr(str(w))+")\nr=subprocess.run(['python3','full_gate.py','--tag','v2_reset'],cwd=str(w/'v2/server_eda'))\n(w/'full_gate_exit.json').write_text(json.dumps({'exit':r.returncode}))"
with (w/'full_gate.log').open('w') as f:
 p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('FULL_GATE_PID',p.pid)
