from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,shutil
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';w.mkdir(exist_ok=True);old=h/'kwt_eda_tmp_20261101/project'
upload=h/'Desktop/kwt_eda_upload_20261101/kwt_v1_frozen_20261101.zip'
assert hashlib.sha256(upload.read_bytes()).hexdigest()=='1e814b7c3235597cc650893bd0d9ca6569fc9a4521ab1e6441d829c32112932c'
with zipfile.ZipFile(str(upload)) as z:
 for p in list((old/'rtl').glob('*.sv'))+[old/'integration/e203_subsys_nice_core.v']:
  assert p.read_bytes()==z.read('v1/'+p.relative_to(old).as_posix())
target=w/'v1.zip';assert not target.exists()
files=[]
for p in old.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(old)
 if any(x in ['tmp','csrc','work','__pycache__','simv.daidir'] or x.endswith('_sim.daidir') for x in rel.parts):continue
 if rel.parts[0]=='build' and p.suffix not in ['.log','.rpt','.json','.txt','.v','.sdf','.sdc']:continue
 files.append(p)
manifest={p.relative_to(old).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(str(target),'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(str(p),'v1/'+p.relative_to(old).as_posix())
 z.writestr('v1/RELEASE_MANIFEST.json',json.dumps({'version':'v1-server','sha256':manifest},indent=2))
with zipfile.ZipFile(str(target)) as z:
 for n,d in manifest.items():assert hashlib.sha256(z.read('v1/'+n)).hexdigest()==d
record={'archive':str(target),'files':len(files),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'rtl_equal_local_v1':True}
(w/'v1_package.json').write_text(json.dumps(record,indent=2));print('V1_FROZEN',json.dumps(record))
shutil.copy2(str(h/'kwt_eda_tmp_20261101/library_selection.json'),str(w/'library_selection.json'))
