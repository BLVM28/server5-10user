from pathlib import Path
import hashlib,json,zipfile,shutil
ws=Path(__file__).resolve().parents[3];old=ws/'v1';new=ws/'v2';out=ws/'releases/20261101_v2'
assert not new.exists();out.mkdir(parents=True,exist_ok=True);archive=out/'v1.zip';assert not archive.exists()
files=[p for p in old.rglob('*') if p.is_file() and not any(x in ['dist','__pycache__'] for x in p.relative_to(old).parts)]
manifest={str(p.relative_to(old)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,'v1/'+p.relative_to(old).as_posix())
 z.writestr('v1/RELEASE_MANIFEST.json',json.dumps({'version':'v1','sha256':manifest},indent=2))
with zipfile.ZipFile(archive) as z:
 for n,sha in manifest.items():assert hashlib.sha256(z.read('v1/'+n)).hexdigest()==sha
shutil.copytree(old,new,ignore=shutil.ignore_patterns('dist','build','__pycache__'))
(new/'build').mkdir();(new/'dist').mkdir()
record={'file':str(archive),'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
(out/'v1_package.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record))
