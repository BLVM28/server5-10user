from pathlib import Path
import re,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';print('STAGES')
lines=(w/'candidate_r3.log').read_text().splitlines()
print('\n'.join([s for s in lines if s.startswith(('python3','regression','compile ','run ','dc ','pt ','make:','Error','ALL PASS','BENCHMARK'))][-25:]))
p=w/'candidate_r3_exit.json'
if p.exists():print('EXIT',p.read_text())
b=w/'v2/build/v2_150'
for p in b.glob('*_result.json'):
 d=json.loads(p.read_text());print('RESULT',p.name,d['completed'],d.get('timing_slack_met',''))
 if not d['completed']:print('ERROR',d.get('error','')[-1000:])
for p in b.glob('sta_*/metrics.txt'):print(p.parent.name,p.read_text().strip())
for p in b.glob('synth_*/dc.log'):print(p.parent.name,'TAIL',' '.join(p.read_text(errors='replace').splitlines()[-3:]))
