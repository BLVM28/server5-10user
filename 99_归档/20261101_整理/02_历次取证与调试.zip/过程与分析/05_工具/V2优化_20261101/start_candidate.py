from pathlib import Path,PurePosixPath
import os,zipfile,json,hashlib,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';src=h/'Desktop/kwt_eda_upload_20261101/v2_candidate_r1.zip'
assert not (w/'v2').exists()
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='v2' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(w));m=json.loads(z.read('v2/RELEASE_MANIFEST.json'))
 for n,d in m['sha256'].items():assert hashlib.sha256((w/'v2'/n).read_bytes()).hexdigest()==d
env=os.environ.copy()
for k in ['TMPDIR','TEMP','TMP']:env[k]=str(w/'tmp')
job="""import subprocess,json
from pathlib import Path
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_versions_20261101')
cmd=['make','all','PERIOD=5.0','TAG=v2_200','HOLD_FIX=1']
r=subprocess.run(cmd,cwd=str(w/'v2/server_eda'))
(w/'candidate_r1_exit.json').write_text(json.dumps({'command':cmd,'exit':r.returncode}))
"""
with (w/'candidate_r1.log').open('w') as f:
 p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('V2_UPLOADED',len(m['sha256']),hashlib.sha256(src.read_bytes()).hexdigest(),'PID',p.pid)
