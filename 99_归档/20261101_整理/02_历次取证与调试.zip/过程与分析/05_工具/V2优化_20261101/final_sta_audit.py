from pathlib import Path,PurePosixPath
import zipfile,os,subprocess,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';r=w/'v2'
assert (w/'baseline_final_exit.json').exists() and (w/'full_gate_exit.json').exists()
with zipfile.ZipFile(str(h/'Desktop/kwt_eda_upload_20261101/flow_audit.zip')) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='server_eda' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(r))
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
job='import subprocess,json\nfrom pathlib import Path\nw=Path('+repr(str(w))+')\nrows=[]\n'
cmds=[['make','sta','summary','TAG=v2_reset'],['make','sta','summary','TAG=v1_reset','RTL_ROOT='+str(h/'kwt_eda_tmp_20261101/project')]]
job+='for cmd in '+repr(cmds)+':\n p=subprocess.run(cmd,cwd=str(w/"v2/server_eda"));rows.append({"cmd":cmd,"exit":p.returncode})\n if p.returncode:break\n'
job+='(w/"sta_audit_exit.json").write_text(json.dumps(rows))\n'
with (w/'sta_audit.log').open('w') as f:p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('STA_AUDIT_PID',p.pid)
