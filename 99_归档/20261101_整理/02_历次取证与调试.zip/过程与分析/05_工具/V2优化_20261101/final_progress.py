from pathlib import Path
import json,re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';r=w/'v2'
for n in ['v2_final_checks','benchmark_final','baseline_final']:
 p=w/(n+'_exit.json');print('JOB',n,p.read_text() if p.exists() else 'RUNNING')
 print((w/(n+'.log')).read_text()[-700:])
for tag in ['v2_reset','v1_reset']:
 for p in (r/'build'/tag).glob('sta_*/metrics.txt'):print(tag,p.parent.name,p.read_text().strip())
 for p in (r/'build'/tag).glob('synth_*/area.rpt'):
  print(tag,p.parent.name,*[x.strip() for x in p.read_text().splitlines() if 'Total cell area:' in x or 'Macro/Black Box area:' in x])
p=r/'build/benchmark_comparison.json'
if p.exists():
 d=json.loads(p.read_text());print('BENCH',d.get('first_12_layer_cycles'),d.get('first_12_layer_nice_cycles'));print('TB_SHA',d['tb_sha256'])
