from pathlib import Path
import json,re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';root=w/'v2'
for name in ['reset_repair_r1','benchmark_counter']:
 print('JOB',name);p=w/(name+'_exit.json');print('EXIT',p.read_text() if p.exists() else 'RUNNING')
 print((w/(name+'.log')).read_text()[-1200:])
for p in (root/'build/v2_reset').glob('synth_*/dc.log'):
 print(p.parent.name,*[s for s in p.read_text().splitlines() if re.search(r'^Error:|RESET_REPAIR|No mapped',s)])
for p in (root/'build/v2_reset').glob('sta_*/metrics.txt'):print(p.parent.name,p.read_text().strip())
p=root/'build/benchmark_comparison.json'
if p.exists():
 d=json.loads(p.read_text());print('BENCH_TOTAL',d.get('first_12_layer_cycles'),d.get('first_12_layer_nice_cycles'))
 print('BENCH_FIRST',[(v,x['rows'][0]) for v,x in d['versions'].items()])
