from pathlib import Path
import os,subprocess,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';assert (w/'candidate_r3_exit.json').exists()
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
job="""import subprocess,json
from pathlib import Path
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_versions_20261101')
cmd=['make','synth','repair','sta','gate','PERIOD=6.666667','RAW_TAG=v1_sameflow_150','TAG=v1_reset','HOLD_FIX=1','RTL_ROOT=/storage2/2026contest/server5/s5_10usr/kwt_eda_tmp_20261101/project']
r=subprocess.run(cmd,cwd=str(w/'v2/server_eda'))
(w/'baseline_exit.json').write_text(json.dumps({'command':cmd,'exit':r.returncode}))
"""
with (w/'baseline_sameflow.log').open('w') as f:
 p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('CONTROLLED_BASELINE_PID',p.pid)
