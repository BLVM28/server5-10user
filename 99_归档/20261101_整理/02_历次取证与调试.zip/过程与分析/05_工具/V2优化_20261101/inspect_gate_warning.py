from pathlib import Path
import json,re
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
b=h/'kwt_versions_20261101/v2/build/v2_200'
d=json.loads((b/'gate_result.json').read_text());print('GATE_ERROR',d.get('error'))
s=(b/'gate/sdf_annotation.log').read_text();lines=s.splitlines()
for i,line in enumerate(lines):
 if re.search('Warning|Error|Total errors|Total warnings',line):print('\n'.join(lines[max(0,i-1):i+4]))
print('DC_AREA')
for p in b.glob('synth_*/area.rpt'):
 print(p.parent.name,*[l.strip() for l in p.read_text().splitlines() if 'Total cell area:' in l or 'Macro/Black Box area:' in l])
