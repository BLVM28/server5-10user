from pathlib import Path
ws=Path(__file__).resolve().parents[3];r=ws/'v2';s=(r/'tb/tb_kwt_system.sv').read_text()
s=s.replace('module tb_kwt_system;','module tb_kwt_overlap;\n  integer overlap_cycles=0,held_mac_cycles=0;')
s=s.replace('wait_count<=rng[5:3]','wait_count<=(transactions%97==0 ? 128 : rng[5:3])')
s=s.replace('      rng<=','      if(dut.core.state==15 && dut.core.prefetch_state==2)overlap_cycles=overlap_cycles+1;\n      if(dut.core.mac_ov && dut.core.state!=13)held_mac_cycles=held_mac_cycles+1;\n      rng<=')
start=s.index('    reset_all();\n    for(l=0;l<12;');end=s.index('  initial begin #200000000',start)
s=s[:start]+'''    reset_all();
    full_case(0,1);
    prepare(0);error_enable=1;error_addr=YBASE+4;launch();finish_task(3,1);tests=tests+1;
    full_case(11,1); // Must recover without global reset after aborting prefetch.
    abort_stage(15);
    full_case(0,1);
    if(overlap_cycles==0 || held_mac_cycles==0)$fatal(1,"overlap/backpressure scenario not reached");
    $display("ALL PASS, %0d/5 overlap/error-recovery scenarios overlap_cycles=%0d held_mac_cycles=%0d",tests,overlap_cycles,held_mac_cycles);$finish;
  end
'''+s[end:]
(r/'tb/tb_kwt_overlap.sv').write_text(s,encoding='utf-8')
