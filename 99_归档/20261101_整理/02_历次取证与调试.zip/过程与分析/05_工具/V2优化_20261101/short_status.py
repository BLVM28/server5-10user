from pathlib import Path
import re,collections
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';r=w/'v2/build'
s=(r/'v2_reset/sta_kwt_nice_core_ss/untested.rpt').read_text();lines=s.splitlines()
print('UNTESTED_REASONS',dict(collections.Counter(re.findall(r'untested\s+(\w+)',s))))
print('UNTESTED_EXAMPLES\n'+'\n'.join(lines[8:25]))
for n in ['full_gate','baseline_final']:
 p=w/(n+'_exit.json');print('JOB',n,p.read_text() if p.exists() else 'RUNNING');print((w/(n+'.log')).read_text()[-800:])
p=r/'v2_reset/full_gate/run.log'
if p.exists():print('FULL_GATE_RUN_BYTES',p.stat().st_size,'TAIL',p.read_text()[-1200:])
for p in (r/'v1_reset').glob('sta_*/metrics.txt'):print(p.parent.name,p.read_text().strip())
for p in (r/'v1_reset').glob('synth_*/area.rpt'):print(p.parent.name,*[x.strip() for x in p.read_text().splitlines() if 'Total cell area:' in x])
