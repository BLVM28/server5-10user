from pathlib import Path
import zipfile,json,hashlib,sys
ws=Path(__file__).resolve().parents[3];root=ws/'v2';name=sys.argv[1]
out=ws/'releases/20261101_v2'/name;assert not out.exists()
files=[p for p in root.rglob('*') if p.is_file() and not any(x in ['build','dist','__pycache__'] for x in p.relative_to(root).parts)]
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,'v2/'+p.relative_to(root).as_posix())
 z.writestr('v2/RELEASE_MANIFEST.json',json.dumps({'version':'v2-candidate','sha256':manifest},indent=2))
print(json.dumps({'file':str(out),'files':len(files),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
