from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parents[3];r=w/'v2'
sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'rtl').glob('*.sv')}
combined=hashlib.sha256(''.join(sha[k] for k in sorted(sha)).encode()).hexdigest()
assert combined=='dedfc56f854c0e5e97e60ef94661aba85d966610f3944e94115e64a3bf88a3a8'
for name in ['v2_overlap','v2_overlap_fallback']:
 d=json.loads((r/'build'/name/'results.json').read_text())
 for k,v in d['source_sha256'].items():
  if k.replace('\\','/').startswith('rtl/'):assert sha[Path(k.replace('\\','/')).name]==v
obj={'date':'2026-11-01','provenance':'MANUAL VNC OBSERVATION SUMMARY. Not downloaded raw server logs.',
 'evidence_directory':'../../过程与分析/05_工具/V2优化_20261101',
 'server_root':'/storage2/2026contest/server5/s5_10usr/kwt_versions_20261101',
 'rtl_sha256':sha,'rtl_hash_of_sorted_hashes':combined,
 'verified_source_matches':['VCS functional','activation','overlap','pipeline','DC synthesis','benchmark','local XSim final and fallback'],
 'period_ns':6.666667,'clock_uncertainty_ns':0.1,'io_max_ns':1.0,'io_min_ns':0.1,'input_transition_ns':0.1,'output_load_pf':0.002852,
 'bench':{'tb_sha256':'f0240db31240f64b32666e734ac4f09c10a216304a7908b08075df9cf98d1ccf','memory_wait_count':2,'tb_clock_ns':10,
 'core_cycles_12':{'v1':4837644,'v2':3859980},'nice_cycles_12':{'v1':4838364,'v2':3860700},'nice_cycle_reduction_pct':100*(4838364-3860700)/4838364,'same_clock_speedup':4838364/3860700},
 'timing_ns':{
 'v1_original':{'dot_ss':[.002894,-.071293],'dot_ff':[3.930200,.013860],'core_ss':[.000123,-.046896],'core_ff':[3.828464,-.145295]},
 'v1_sameflow':{'dot_ss':[.003661,.449117],'dot_ff':[3.930788,.191499],'core_ss':[.000217,.384746],'core_ff':[3.731268,.199938]},
 'v2_final':{'dot_ss':[.006241,.336904],'dot_ff':[4.393198,.200376],'core_ss':[.000262,.399041],'core_ff':[3.500699,.192947]}},
 'total_cell_area_library_units':{'v1_original_core':127551.855752,'v1_sameflow_core':137444.502288,'v2_core':147845.634293,'v1_original_dot':3116.030403,'v1_sameflow_dot':3665.054420,'v2_dot':4948.557612,'core_sram_macro':85456.079102},
 'tests':{'arithmetic':'260/260','icb':'4/4','matrix':'29/29','activation':'29/29','overlap':'5/5','multiplier_boundaries':'524288/524288','multiplier_total_compared':527566,'fallback_local':'29/29','e203_binding':'29/29','sram_timing_model':'1186/1186','dot_rtl':'32/32','v2_dot_sdf':'32/32','v1_sameflow_dot_sdf':'32/32','v2_core_sdf_layer0':'1/1'},
 'sdf_annotation_errors':0,'sdf_annotation_warnings':0,
 'v2_reported_constraints_met':False,'v2_max_min_slack_met':True,
 'cap_violations_ss':[{'pin':'master/U381/ZN','limit_pf':.072321,'actual_pf':.073936},{'pin':'U1770/Z','limit_pf':.074552,'actual_pf':.074555}],
 'core_sta_coverage':{'total':22482,'met':18765,'untested':3717,'setup_hold_each_total':3670,'setup_hold_each_met':3512,'setup_hold_each_untested':158,'recovery_removal_each_met':2884},
 'limits':['pre-layout only; no CTS/SPEF/OCV/signoff','tiny SS setup margin and two cap violations','actual shared memory address unresolved','no E203 CPU full SoC run','no official speech validation set or full-model timing','one full-core gate layer, not all corner/state dynamic coverage']}
(r/'build/server_observed_v2.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('OBSERVED_SUMMARY_WRITTEN_AND_LOCAL_HASHES_VERIFIED',combined)
