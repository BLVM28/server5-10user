from pathlib import Path,PurePosixPath
import zipfile,os,subprocess,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';root=w/'v2';assert (w/'candidate_r3_exit.json').exists()
src=h/'Desktop/kwt_eda_upload_20261101/reset_repair_r1.zip'
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='server_eda' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(root))
for name in ['benchmark_v1','benchmark_v2']:
 old=root/'build'/name;dest=root/'build'/(name+'_core_only');assert old.resolve().parent==(root/'build').resolve() and not dest.exists();old.rename(dest)
env=os.environ.copy()
for k in ['TMPDIR','TMP','TEMP']:env[k]=str(w/'tmp')
jobs={
'reset_repair_r1':[['python3','repair_reset.py'],['make','sta','gate','summary','TAG=v2_reset']],
'benchmark_counter':[['make','benchmark']]}
for name,commands in jobs.items():
 job="import subprocess,json\nfrom pathlib import Path\nw=Path("+repr(str(w))+")\nrows=[]\n"
 job+="for cmd in "+repr(commands)+":\n r=subprocess.run(cmd,cwd=str(w/'v2/server_eda'));rows.append({'cmd':cmd,'exit':r.returncode})\n if r.returncode:break\n"
 job+="(w/"+repr(name+'_exit.json')+").write_text(json.dumps(rows))\n"
 with (w/(name+'.log')).open('w') as f:
  p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print('JOB',name,p.pid)
