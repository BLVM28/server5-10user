from pathlib import Path
r=Path(__file__).resolve().parents[3]/'v2'
p=r/'README.md';s=p.read_text(encoding='utf-8')
s=s.replace('# KWT 本科任务 1 和任务 2 RTL 工程','# KWT 本科任务 1 和任务 2 RTL 工程 · v2')
s=s.replace('采用 8 路串行点积、完整 X 缓存、8 列 W 缓存和单笔在途 ICB 访问。','采用 8 路点积、三级精确乘法、完整 X 缓存、8 列 W 缓存和单笔在途 ICB，重叠当前行写回与下一行计算。')
s=s.replace('以下命令均在 `v1` 目录执行','以下命令均在 `v2` 目录执行')
s=s.replace('python py/run_xsim.py --tag rerun\n','python py/run_xsim.py --tag rerun --tops tb_kwt_arithmetic tb_kwt_icb tb_kwt_system tb_kwt_overlap tb_kwt_mul_pipeline\n')
s=s[:s.index('## 后续服务器 EDA 实测')]+'''## v2 比较与复现

正式对比、时序边界和实测日志位置见 [REPORT_V1_V2.md](REPORT_V1_V2.md)，架构依据见 [ARCHITECTURE_V2.md](ARCHITECTURE_V2.md)。固定延迟总线的 12 次 NICE 任务从 4,838,364 降至 3,860,700 拍，减少 20.2065%；这不是 CPU 整机计时或语音识别准确率。

服务器 `kwt_versions_20261101/v2/server_eda` 执行 `make all`。最终映射结果在 `build/v2_reset`，修复前结果在 `build/v2_150`；保留所有失败与试验记录。服务器实际库角 max/min slack 均非负，但 SS setup 余量很小、仍有电容及覆盖率限制，不能当作后端签核通过。详细命令见 [server_eda/README.md](server_eda/README.md)。

本地 `build/v2_overlap` 与 `build/v2_overlap_fallback` 为最终 RTL 回归；`v2_pipeline`、`v2_multiplier_exhaustive`、`v2_swap_fallback` 是改良过程的早期记录。服务器摘要 `build/server_observed_v2.json` 明确标注为 VNC 观察整理，原始服务器日志没有下载。

本地冻结包位于 `../releases/20261101_v2/v1.zip` 与 `v2.zip`，服务器包位于个人工作目录下 `kwt_versions_20261101`。两地日志内容不同，ZIP 哈希不同；RTL、向量逐文件比对。包内 `RELEASE_MANIFEST.json` 是版本清单；继承的 `MANIFEST*.json` 仅记录旧 v1 发布历史，不能用于校验 v2。
'''
p.write_text(s,encoding='utf-8')
p=r/'validation.md';s=p.read_text(encoding='utf-8');old=s[s.index('## 原模型和精度检查'):s.index('## 周期与综合的实际含义')]
p.write_text('''# v2 验证记录

日期：2026-11-01。最终结论、比较条件及未通过项以 [REPORT_V1_V2.md](REPORT_V1_V2.md) 为准。下面区分最终 RTL 测试、布局前网表测试和继承的数值证据。

| 最终 v2 检查 | 实际结果 | 范围 / 证据 |
|---|---|---|
| XSim 2023.2 算术 / ICB / 矩阵 | 260/260、4/4、29/29 | `build/v2_overlap/results.json`，与当前 RTL 哈希核对 |
| 乘法专项 | 524288/524288 边界组合 | 8 个 X 边界 × 所有 W；另含随机、气泡、异步复位、各流水占用时同步 clear，总比较 527566 |
| overlap 专项 | 5/5 | 长背压、待写结果保持、写错误后不复位再启动、在途写复位 |
| 半字交换 / 大 W 宏回退 | 29/29 | `build/v2_overlap_fallback`，PACK=0、WAW=10 |
| VCS 真实宏功能分支 | 260/260、4/4、29/29、5/5 | 服务器 `build/server_functional`、`server_overlap`；ARM_UD_MODEL |
| VCS 原模型静音各层输入 | 29/29 | 服务器 `build/server_activation` |
| 实际 E203 头文件 + NICE 包装 | 29/29 | 服务器 `build/e203_binding`；不是 CPU 整机 |
| SRAM 默认时序模型 / dot RTL | 1186/1186、32/32 | 服务器 `build/v2_150`，约 150 MHz |
| dot 映射网表 + SS SDF | 32/32 | 服务器 `build/v2_reset/gate`；0 回标错误/警告 |
| 同 TB 的 v1 / v2 比较 | 各 29/29 | 服务器 `build/benchmark_comparison.json`，固定响应等待 2，比较同一 TB 哈希 |

矩阵测试逐项比较 25,344 个 40 位累加和及 25,344 个 int16 输出，检查 24,296 个事务、12,672 次写应答、输出 guard、饱和计数。12 层之间不复位；检查忙时拒绝命令、响应背压稳定以及地址、指令、读写错误。金模和全部 159 个向量文件与 v1 相同，未改期望值迁就流水实现。

v2 的三级乘法改变内部延迟，valid/last 同步传递；新增 clear 同步撤销无效计算。旧 FPGA 结构统计（8 DSP、2187 LUT 等）来自 v1，不能作为 v2 的资源数据。本次以实际 SMIC40 DC 面积与 PT 拓扑为准。

完整核心 SDF 动态测试、最终面积和时序覆盖详情见对比报告。所有服务器原始日志、网表、SDF 留在工作目录；本地只保存明确标记的观察摘要。

'''+old+'''
## 尚未覆盖的验收

尚未运行真实 E203 CPU 程序、正式共享 RAM、全语音验证集或物理后端签核。`MEM_BASE/MEM_BYTES=0` 默认拒绝任务；0x10000000 仍为测试地址。不能把独立 12 层第一 Dense 的回归当成完整语音识别模型或官方计时。
''',encoding='utf-8')
