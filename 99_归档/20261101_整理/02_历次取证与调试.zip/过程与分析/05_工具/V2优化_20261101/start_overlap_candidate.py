from pathlib import Path,PurePosixPath
import zipfile,os,json,hashlib,subprocess
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';assert (w/'candidate_r1_exit.json').exists()
old=w/'v2';backup=w/'v2_pipeline_only_r1';assert old.resolve().parent==w.resolve() and not backup.exists()
old.rename(backup)
src=h/'Desktop/kwt_eda_upload_20261101/v2_candidate_r3.zip'
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='v2' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(w));m=json.loads(z.read('v2/RELEASE_MANIFEST.json'))
 for n,d in m['sha256'].items():assert hashlib.sha256((w/'v2'/n).read_bytes()).hexdigest()==d
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
job="""import subprocess,json
from pathlib import Path
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_versions_20261101')
cmd=['make','all','PERIOD=6.666667','TAG=v2_150','HOLD_FIX=1']
r=subprocess.run(cmd,cwd=str(w/'v2/server_eda'))
(w/'candidate_r3_exit.json').write_text(json.dumps({'command':cmd,'exit':r.returncode}))
"""
with (w/'candidate_r3.log').open('w') as f:
 p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
print('V2_R3_UPLOADED',len(m['sha256']),hashlib.sha256(src.read_bytes()).hexdigest(),'PID',p.pid)
