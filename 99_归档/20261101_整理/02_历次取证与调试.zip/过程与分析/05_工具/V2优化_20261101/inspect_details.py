from pathlib import Path
import re,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';r=w/'v2/build/v2_reset'
p=r/'sta_kwt_nice_core_ss/untested.rpt';s=p.read_text();print('UNTESTED HEAD\n'+s[:2600]);print('UNTESTED TAIL\n'+s[-1500:])
p=r/'synth_kwt_nice_core/check_design.rpt';s=p.read_text();print('LINT HEAD\n'+s[:1300]);print('LINT2 EXAMPLES','\n'.join(x for x in s.splitlines() if '(LINT-2)' in x)[:700])
for n in ['full_gate','baseline_final']:
 p=w/(n+'_exit.json');print('JOB',n,p.read_text() if p.exists() else 'RUNNING');print((w/(n+'.log')).read_text()[-600:])
for p in (w/'v2/build/v1_reset').glob('sta_*/metrics.txt'):print(p.parent.name,p.read_text().strip())
for p in (w/'v2/build/v1_reset').glob('synth_*/area.rpt'):print(p.parent.name,*[x.strip() for x in p.read_text().splitlines() if 'Total cell area:' in x])
