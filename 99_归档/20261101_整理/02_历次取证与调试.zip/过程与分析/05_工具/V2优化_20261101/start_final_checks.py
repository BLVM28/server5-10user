from pathlib import Path,PurePosixPath
import zipfile,os,subprocess,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';root=w/'v2'
assert (w/'reset_repair_r1_exit.json').exists()
src=h/'Desktop/kwt_eda_upload_20261101/flow_final_r2.zip'
with zipfile.ZipFile(str(src)) as z:
 for n in z.namelist():
  p=PurePosixPath(n);assert p.parts[0]=='server_eda' and '..' not in p.parts and not p.is_absolute()
 z.extractall(str(root))
env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
jobs={'v2_final_checks':[['make','sta','gate','summary','TAG=v2_reset']],
      'benchmark_final':[['make','benchmark']],
      'baseline_final':[['make','synth','repair','sta','gate','PERIOD=6.666667','RAW_TAG=v1_sameflow_150','TAG=v1_reset','HOLD_FIX=1','RTL_ROOT='+str(h/'kwt_eda_tmp_20261101/project')]]}
for name,commands in jobs.items():
 job='import subprocess,json\nfrom pathlib import Path\nw=Path('+repr(str(w))+')\nrows=[]\n'
 job+='for cmd in '+repr(commands)+':\n r=subprocess.run(cmd,cwd=str(w/"v2/server_eda"));rows.append({"cmd":cmd,"exit":r.returncode})\n if r.returncode:break\n'
 job+='(w/'+repr(name+'_exit.json')+').write_text(json.dumps(rows))\n'
 with (w/(name+'.log')).open('w') as f:
  p=subprocess.Popen(['python3','-u','-c',job],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print('JOB',name,p.pid)
