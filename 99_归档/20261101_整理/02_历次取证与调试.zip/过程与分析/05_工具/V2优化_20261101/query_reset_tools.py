from pathlib import Path
import os,subprocess,json
h=Path('/storage2/2026contest/server5/s5_10usr');assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_versions_20261101';env=os.environ.copy()
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(w/'tmp')
p=w/'reset_help.tcl';p.write_text('help -verbose all_registers\nhelp -verbose reset_path\nhelp -verbose set_min_delay\nhelp -verbose insert_buffer\nexit\n')
with (w/'reset_help.log').open('w') as f:
 subprocess.run(['dc_shell','-f',str(p)],cwd=str(w),env=env,stdout=f,stderr=subprocess.STDOUT)
for line in (w/'reset_help.log').read_text().splitlines():
 if any(x in line for x in ['async_pins','reset_path','min_delay','insert_buffer','new_cell_names','from','to_list']):print(line)
print('R3_EXIT',(w/'candidate_r3_exit.json').read_text() if (w/'candidate_r3_exit.json').exists() else 'RUNNING')
p=w/'v2/build/benchmark_comparison.json'
if p.exists():print('BENCHMARK',json.loads(p.read_text())['first_12_layer_cycles'])
