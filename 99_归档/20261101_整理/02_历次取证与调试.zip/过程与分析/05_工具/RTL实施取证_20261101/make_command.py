"""Encode a short server Python script for csh-safe VNC typing, no credentials."""
import base64,zlib,json,sys
from pathlib import Path
script=Path(sys.argv[1]).read_bytes()
encoded=base64.b64encode(zlib.compress(script)).decode('ascii')
cmd='clear; python3 -u -c "exec(__import__(\'zlib\').decompress(__import__(\'base64\').b64decode(\''+encoded+'\')))"'
assert len(cmd)<3000,'Split uploads into small chunks; remote csh has a line limit'
print(json.dumps({'op':'command','text':cmd,'capture':sys.argv[2],'wait':0.5}))
