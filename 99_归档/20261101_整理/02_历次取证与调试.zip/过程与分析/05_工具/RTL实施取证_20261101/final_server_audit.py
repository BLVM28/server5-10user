from pathlib import Path
import hashlib,json,zipfile
h=Path('/storage2/2026contest/server5/s5_10usr')
assert Path.cwd().resolve()==h.resolve()
w=h/'kwt_foundry_full_20261101'
digest=hashlib.sha256()
for p in sorted((w/'rtl').glob('*.sv')):
 digest.update(p.name.encode());digest.update(p.read_bytes())
print('OWN_RTL_SHA256',digest.hexdigest())
print('OWN_WRAPPER_SHA256',hashlib.sha256((w/'integration/e203_subsys_nice_core.v').read_bytes()).hexdigest())
for folder in ['foundry','foundry_functional','foundry_binding']:
 p=w/'build'/folder/'results.json'
 if p.exists():
  d=json.loads(p.read_text());print('RUN',folder,{k:d.get(k) for k in ['compile_exit','run_exit','passed']})
for p in sorted((w/'include').glob('*.v')):
 print('HEADER',p.name,hashlib.sha256(p.read_bytes()).hexdigest())
z=zipfile.ZipFile('/storage1/admin_public_dir/SOC_RTL_2025/e203_hbirdv2-master_1013_update_sim.zip')
print('TOP_CANDIDATES',*[n for n in z.namelist() if n.endswith('.v') and '/rtl/' in n and any(s in n.lower() for s in ['soc_top','shared','sram_top'])][:15],sep='\n')
