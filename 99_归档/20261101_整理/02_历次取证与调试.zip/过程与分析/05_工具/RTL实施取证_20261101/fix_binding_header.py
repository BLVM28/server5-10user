from pathlib import Path
import subprocess,zipfile
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_foundry_full_20261101')
p=w/'py/run_binding_server.py'
s=p.read_text().replace("'e203_config.v'","'config.v'")
p.write_text(s)
subprocess.run(['python3','-u',str(p)],cwd=str(w))
