import pathlib,os,subprocess,json,hashlib,base64
base=pathlib.Path('/storage2/2026contest/server5/s5_10usr')
assert pathlib.Path.cwd().resolve()==base.resolve()
work=base/'kwt_rtl_probe_20261101_r2'
work.mkdir(exist_ok=True)
assert work.resolve().parent==base.resolve()
(work/'tmp').mkdir(exist_ok=True)
(work/'tb_foundry_sram.sv').write_bytes(base64.b64decode('YHRpbWVzY2FsZSAxbnMvMXBzCm1vZHVsZSB0Yl9mb3VuZHJ5X3NyYW07CiAgcmVnIGNsaz0wOyBhbHdheXMgIzUgY2xrPX5jbGs7CiAgcmVnIGNlbj0xLGd3ZW49MTsgcmVnIFsxNTowXSB3ZW49MTYnaGZmZmYsZD0wOwogIHJlZyBbOTowXSBhPTA7CiAgd2lyZSBbMTU6MF0gcTEyOCxxMTAyNDsKICBpbnRlZ2VyIHRlc3RzPTA7CiAgUkFNU1AxMjhYMTZfcnRsX3RvcCByMTI4KC5DTEsoY2xrKSwuQ0VOKGNlbiksLkdXRU4oZ3dlbiksLldFTih3ZW4pLAogICAgLkEoYVs2OjBdKSwuRChkKSwuUShxMTI4KSwuRU1BKDMnZDIpLC5FTUFXKDInZDApLC5SRVQxTigxJ2IxKSk7CiAgUkFNU1AxMDI0WDE2X3J0bF90b3AgcjEwMjQoLkNMSyhjbGspLC5DRU4oY2VuKSwuR1dFTihnd2VuKSwuV0VOKHdlbiksCiAgICAuQShhKSwuRChkKSwuUShxMTAyNCksLkVNQSgzJ2QyKSwuRU1BVygyJ2QwKSwuUkVUMU4oMSdiMSkpOwogIHRhc2sgYWNjZXNzKGlucHV0IGJpdCB3cml0ZV9hY2Nlc3MsaW5wdXQgWzk6MF0gYWRkcmVzcyxpbnB1dCBbMTU6MF0gZGF0YSxtYXNrKTsKICAgIGJlZ2luIEAobmVnZWRnZSBjbGspOyBjZW49MDtnd2VuPSF3cml0ZV9hY2Nlc3M7YT1hZGRyZXNzO2Q9ZGF0YTt3ZW49bWFzazsKICAgICAgLy8gVGltaW5nIG1vZGVsIGRlZmF1bHQgY2xvY2stdG8tUSBpcyAxIG5zOyBzYW1wbGUgYmV5b25kIHRoYXQgYm91bmRhcnkuCiAgICAgIEAocG9zZWRnZSBjbGspOyAjMjsgZW5kCiAgZW5kdGFzawogIHRhc2sgY2hlY2soaW5wdXQgWzE1OjBdIGV4cGVjdGVkKTsKICAgIGJlZ2luIGlmKHExMjghPT1leHBlY3RlZCB8fCBxMTAyNCE9PWV4cGVjdGVkKQogICAgICAkZmF0YWwoMSwibWFjcm8gbWlzbWF0Y2ggZXhwZWN0ZWQ9JWggc3AxMjg9JWggc3AxMDI0PSVoIixleHBlY3RlZCxxMTI4LHExMDI0KTsKICAgICAgdGVzdHM9dGVzdHMrMTsgZW5kCiAgZW5kdGFzawogIGluaXRpYWwgYmVnaW4KICAgIGFjY2VzcygxLDAsMTYnaDEzNTcsMTYnaDAwMDApOyBhY2Nlc3MoMCwwLDAsMTYnaGZmZmYpOyBjaGVjaygxNidoMTM1Nyk7CiAgICBhY2Nlc3MoMSwwLDE2J2gwMGEwLDE2J2hmZjBmKTsgYWNjZXNzKDAsMCwwLDE2J2hmZmZmKTsgY2hlY2soMTYnaDEzYTcpOwogICAgYWNjZXNzKDEsMTI3LDE2J2g4MDAxLDE2J2gwMDAwKTsgYWNjZXNzKDAsMTI3LDAsMTYnaGZmZmYpOyBjaGVjaygxNidoODAwMSk7CiAgICBAKG5lZ2VkZ2UgY2xrKTtjZW49MTthPTA7IEAocG9zZWRnZSBjbGspOyMyOyBjaGVjaygxNidoODAwMSk7CiAgICBhY2Nlc3MoMCwwLDAsMTYnaGZmZmYpOyBjaGVjaygxNidoMTNhNyk7CiAgICBhY2Nlc3MoMSwxLDE2J2hmZmZmLDE2J2gwMDAwKTsgYWNjZXNzKDEsMiwxNidoMDAwMCwxNidoMDAwMCk7CiAgICBhY2Nlc3MoMCwxLDAsMTYnaGZmZmYpO2NoZWNrKDE2J2hmZmZmKTthY2Nlc3MoMCwyLDAsMTYnaGZmZmYpO2NoZWNrKDApOwogICAgJGRpc3BsYXkoIkFMTCBQQVNTLCAlMGQvNyByZWFsIFNQMTI4L1NQMTAyNCBtYWNybyBjaGVja3MiLHRlc3RzKTskZmluaXNoOwogIGVuZAogIGluaXRpYWwgYmVnaW4gIzEwMDAwOyRmYXRhbCgxLCJ0aW1lb3V0Iik7ZW5kCmVuZG1vZHVsZQo='))
env=os.environ.copy()
env['TMPDIR']=str(work/'tmp')
env['TMP']=env['TMPDIR'];env['TEMP']=env['TMPDIR']
sources=[]
for macro in ['RAMSP128X16','RAMSP1024X16']:
 for suffix in ['.v','_rtl.v']:
  sources.append('/storage1/admin_public_dir/SRAM_Lib_2025/'+macro+'/verilog/'+macro+suffix)
meta={'tb_sha256':hashlib.sha256((work/'tb_foundry_sram.sv').read_bytes()).hexdigest(),'cwd':str(work),'sources':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in sources}}
with (work/'compile.log').open('w') as log:
 r=subprocess.run(['vcs','-full64','-sverilog','-timescale=1ns/1ps','-top','tb_foundry_sram',*sources,'tb_foundry_sram.sv','-o','simv'],cwd=str(work),env=env,stdout=log,stderr=subprocess.STDOUT)
meta['compile_exit']=r.returncode
if r.returncode==0:
 with (work/'run.log').open('w') as log:
  r=subprocess.run([str(work/'simv')],cwd=str(work),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 meta['run_exit']=r.returncode
 print((work/'run.log').read_text()[-2500:])
else: print((work/'compile.log').read_text()[-4000:])
(work/'result.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(meta,indent=2))
