from pathlib import Path
import subprocess
w=Path('/storage2/2026contest/server5/s5_10usr/kwt_foundry_full_20261101')
p=w/'py/run_foundry_server.py'
s=p.read_text().replace("OUT=ROOT/'build'/'foundry'","OUT=ROOT/'build'/'foundry_functional'")
s=s.replace("'+define+KWT_USE_FOUNDRY_SRAM']","'+define+KWT_USE_FOUNDRY_SRAM','+define+ARM_UD_MODEL']")
s=s.replace('NOT E203 SoC; NOT speech accuracy; no SDF/STA','ARM_UD_MODEL functional macro branch; NOT E203 SoC; NOT speech accuracy; no SDF/STA')
p.write_text(s)
subprocess.run(['python3','-u',str(p)],cwd=str(w))
