import zipfile,difflib
z=zipfile.ZipFile('/storage1/admin_public_dir/SOC_RTL_2025/e203_hbirdv2-master_1013_update_sim.zip')
for f in ['subsys/e203_subsys_nice_core.v','core/config.v','core/e203_defines.v','core/e203_cpu.v','soc/e203_soc_top.v']:
 a='e203_hbirdv2-master/rtl/e203/'+f
 b='e203_hbirdv2-master/vsim/install/rtl/'+f
 if a in z.namelist() and b in z.namelist():
  x=z.read(a);y=z.read(b);print(f,'IDENTICAL',x==y,'BYTES',len(x),len(y))
  if x!=y:print(''.join(list(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True)))[:20]))
 else:print(f,'MISSING',a not in z.namelist(),b not in z.namelist())
