import zipfile
z=zipfile.ZipFile('/storage1/admin_public_dir/SOC_RTL_2025/e203_hbirdv2-master_1013_update_sim.zip')
for name in ['e203_defines.v','e203_config.v']:
 for n in z.namelist():
  if n.endswith('/'+name):
   print(n)
   print(*[l for l in z.read(n).decode().splitlines() if l.startswith('`include')],sep='\n')
