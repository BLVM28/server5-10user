import pathlib,re,zipfile
h=pathlib.Path('/storage2/2026contest/server5/s5_10usr')
assert pathlib.Path.cwd().resolve()==h.resolve()
for name in ['RAMSP1024X16','RAMSP128X16']:
 p=pathlib.Path('/storage1/admin_public_dir/SRAM_Lib_2025')/name
 fs=list(p.rglob('*.lib'))
 print('LIBS',*[str(x) for x in fs[:2]],sep='\n')
 if fs:
  s=fs[0].read_text()
  print('LIB_CELLS',*[m.group(0) for m in re.finditer(r'cell\s*\([^)]*\)',s)])
  print('AREA',*[m.group(0) for m in re.finditer(r'area\s*:\s*[^;]+',s)][:3])
 v=p/'verilog'/(name+'.v')
 print('MODULES',*[x for x in v.read_text().splitlines() if x.startswith('module ')])
z=zipfile.ZipFile('/storage1/admin_public_dir/SOC_RTL_2025/e203_hbirdv2-master_1013_update_sim.zip')
n=[n for n in z.namelist() if n.endswith('/rtl/e203/subsys/e203_subsys_nice_core.v')][0]
print('NICE_HEADER',*[x for x in z.read(n).decode().splitlines()[:28] if '`include' in x or '`ifdef' in x])
