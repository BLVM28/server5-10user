import pathlib,os,subprocess,json,hashlib,base64
base=pathlib.Path('/storage2/2026contest/server5/s5_10usr')
assert pathlib.Path.cwd().resolve()==base.resolve()
work=base/'kwt_rtl_probe_20261101'
work.mkdir(exist_ok=True)
assert work.resolve().parent==base.resolve()
(work/'tmp').mkdir(exist_ok=True)
(work/'tb_foundry_sram.sv').write_bytes(base64.b64decode('YHRpbWVzY2FsZSAxbnMvMXBzCm1vZHVsZSB0Yl9mb3VuZHJ5X3NyYW07CiAgcmVnIGNsaz0wOyBhbHdheXMgIzUgY2xrPX5jbGs7CiAgcmVnIGNlbj0xLGd3ZW49MTsgcmVnIFsxNTowXSB3ZW49MTYnaGZmZmYsZD0wOwogIHJlZyBbOTowXSBhPTA7CiAgd2lyZSBbMTU6MF0gcTEyOCxxMTAyNDsKICBpbnRlZ2VyIHRlc3RzPTA7CiAgUkFNU1AxMjhYMTZfcnRsX3RvcCByMTI4KC5DTEsoY2xrKSwuQ0VOKGNlbiksLkdXRU4oZ3dlbiksLldFTih3ZW4pLAogICAgLkEoYVs2OjBdKSwuRChkKSwuUShxMTI4KSwuRU1BKDMnZDIpLC5FTUFXKDInZDApLC5SRVQxTigxJ2IxKSk7CiAgUkFNU1AxMDI0WDE2X3J0bF90b3AgcjEwMjQoLkNMSyhjbGspLC5DRU4oY2VuKSwuR1dFTihnd2VuKSwuV0VOKHdlbiksCiAgICAuQShhKSwuRChkKSwuUShxMTAyNCksLkVNQSgzJ2QyKSwuRU1BVygyJ2QwKSwuUkVUMU4oMSdiMSkpOwogIHRhc2sgYWNjZXNzKGlucHV0IGJpdCB3cml0ZV9hY2Nlc3MsaW5wdXQgWzk6MF0gYWRkcmVzcyxpbnB1dCBbMTU6MF0gZGF0YSxtYXNrKTsKICAgIGJlZ2luIEAobmVnZWRnZSBjbGspOyBjZW49MDtnd2VuPSF3cml0ZV9hY2Nlc3M7YT1hZGRyZXNzO2Q9ZGF0YTt3ZW49bWFzazsKICAgICAgQChwb3NlZGdlIGNsayk7ICMxOyBlbmQKICBlbmR0YXNrCiAgdGFzayBjaGVjayhpbnB1dCBbMTU6MF0gZXhwZWN0ZWQpOwogICAgYmVnaW4gaWYocTEyOCE9PWV4cGVjdGVkIHx8IHExMDI0IT09ZXhwZWN0ZWQpCiAgICAgICRmYXRhbCgxLCJtYWNybyBtaXNtYXRjaCBleHBlY3RlZD0laCBzcDEyOD0laCBzcDEwMjQ9JWgiLGV4cGVjdGVkLHExMjgscTEwMjQpOwogICAgICB0ZXN0cz10ZXN0cysxOyBlbmQKICBlbmR0YXNrCiAgaW5pdGlhbCBiZWdpbgogICAgYWNjZXNzKDEsMCwxNidoMTM1NywxNidoMDAwMCk7IGFjY2VzcygwLDAsMCwxNidoZmZmZik7IGNoZWNrKDE2J2gxMzU3KTsKICAgIGFjY2VzcygxLDAsMTYnaDAwYTAsMTYnaGZmMGYpOyBhY2Nlc3MoMCwwLDAsMTYnaGZmZmYpOyBjaGVjaygxNidoMTNhNyk7CiAgICBhY2Nlc3MoMSwxMjcsMTYnaDgwMDEsMTYnaDAwMDApOyBhY2Nlc3MoMCwxMjcsMCwxNidoZmZmZik7IGNoZWNrKDE2J2g4MDAxKTsKICAgIEAobmVnZWRnZSBjbGspO2Nlbj0xO2E9MDsgQChwb3NlZGdlIGNsayk7IzE7IGNoZWNrKDE2J2g4MDAxKTsKICAgIGFjY2VzcygwLDAsMCwxNidoZmZmZik7IGNoZWNrKDE2J2gxM2E3KTsKICAgIGFjY2VzcygxLDEsMTYnaGZmZmYsMTYnaDAwMDApOyBhY2Nlc3MoMSwyLDE2J2gwMDAwLDE2J2gwMDAwKTsKICAgIGFjY2VzcygwLDEsMCwxNidoZmZmZik7Y2hlY2soMTYnaGZmZmYpO2FjY2VzcygwLDIsMCwxNidoZmZmZik7Y2hlY2soMCk7CiAgICAkZGlzcGxheSgiQUxMIFBBU1MsICUwZC83IHJlYWwgU1AxMjgvU1AxMDI0IG1hY3JvIGNoZWNrcyIsdGVzdHMpOyRmaW5pc2g7CiAgZW5kCiAgaW5pdGlhbCBiZWdpbiAjMTAwMDA7JGZhdGFsKDEsInRpbWVvdXQiKTtlbmQKZW5kbW9kdWxlCg=='))
env=os.environ.copy()
env['TMPDIR']=str(work/'tmp')
env['TMP']=env['TMPDIR'];env['TEMP']=env['TMPDIR']
sources=[]
for macro in ['RAMSP128X16','RAMSP1024X16']:
 for suffix in ['.v','_rtl.v']:
  sources.append('/storage1/admin_public_dir/SRAM_Lib_2025/'+macro+'/verilog/'+macro+suffix)
meta={'cwd':str(work),'sources':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in sources}}
with (work/'compile.log').open('w') as log:
 r=subprocess.run(['vcs','-full64','-sverilog','-timescale=1ns/1ps','-top','tb_foundry_sram',*sources,'tb_foundry_sram.sv','-o','simv'],cwd=str(work),env=env,stdout=log,stderr=subprocess.STDOUT)
meta['compile_exit']=r.returncode
if r.returncode==0:
 with (work/'run.log').open('w') as log:
  r=subprocess.run([str(work/'simv')],cwd=str(work),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 meta['run_exit']=r.returncode
 print((work/'run.log').read_text()[-2500:])
else: print((work/'compile.log').read_text()[-4000:])
(work/'result.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(meta,indent=2))
