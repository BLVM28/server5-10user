#!/usr/bin/env python3
"""Create and verify a private snapshot; never export or alter public files."""
import hashlib
import json
import os
import stat
import tarfile
import tempfile
import time

SOURCE = '/storage1/admin_public_dir'
HOME_ROOT = '/storage2/2026contest/server5/s5_10usr'
SELECTED = ('SOC_RTL_2025', 'SRAM_Lib_2025', 'Document')


def digest_stream(stream):
    digest = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(block)
    return digest.hexdigest()


def digest_file(path):
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(path, flags)
    with os.fdopen(descriptor, 'rb') as source:
        if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
            raise RuntimeError('Not a regular source file: ' + path)
        return digest_stream(source)


class HashingReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()

    def read(self, size=-1):
        block = self.stream.read(size)
        self.digest.update(block)
        return block


def within(path, root):
    return path == root or path.startswith(root + os.sep)


def main():
    if os.path.realpath(SOURCE) != SOURCE:
        raise RuntimeError('Public root resolves elsewhere')
    if os.path.realpath(HOME_ROOT) != HOME_ROOT:
        raise RuntimeError('Private root resolves elsewhere')
    if os.path.realpath(os.getcwd()) != HOME_ROOT:
        raise RuntimeError('Run from the authorised private home directory')
    entries = []
    for selected in SELECTED:
        selected_path = os.path.join(SOURCE, selected)
        if os.path.islink(selected_path) or not os.path.isdir(selected_path):
            raise RuntimeError('Missing regular selected directory: ' + selected)
        entries.append(selected)
        for directory, directories, files in os.walk(selected_path, followlinks=False):
            directories.sort()
            files.sort()
            if not within(os.path.realpath(directory), SOURCE):
                raise RuntimeError('Directory escaped public root')
            for name in directories + files:
                entries.append(os.path.relpath(os.path.join(directory, name), SOURCE))
    if len(entries) != len(set(entries)):
        raise RuntimeError('Duplicate source path')
    staging = tempfile.mkdtemp(prefix='kwt_public_snapshot.', dir=HOME_ROOT)
    archive_path = os.path.join(staging, 'public_rtl_sram.tar.gz')
    manifest_path = os.path.join(staging, 'source_manifest.json')
    records = []
    expected = {}
    with tarfile.open(archive_path, 'w:gz', format=tarfile.PAX_FORMAT,
                      dereference=False, compresslevel=1) as archive:
        for relative in entries:
            absolute = os.path.join(SOURCE, relative)
            before = os.lstat(absolute)
            info = archive.gettarinfo(absolute, arcname=relative)
            record = {'path': relative, 'mode': stat.S_IMODE(before.st_mode),
                      'mtime': before.st_mtime}
            if stat.S_ISLNK(before.st_mode):
                record.update(kind='symlink', target=os.readlink(absolute))
                archive.addfile(info)
            elif stat.S_ISDIR(before.st_mode):
                record['kind'] = 'directory'
                archive.addfile(info)
            elif stat.S_ISREG(before.st_mode):
                if not within(os.path.realpath(absolute), SOURCE):
                    raise RuntimeError('Source escaped public root')
                source_hash = digest_file(absolute)
                if info.islnk():
                    archive.addfile(info)
                    copied_hash = source_hash
                    after = os.lstat(absolute)
                    record['hardlink_target'] = info.linkname
                else:
                    descriptor = os.open(absolute, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
                    with os.fdopen(descriptor, 'rb') as source:
                        opened = os.fstat(source.fileno())
                        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
                            raise RuntimeError('Source identity changed: ' + relative)
                        reader = HashingReader(source)
                        archive.addfile(info, reader)
                        copied_hash = reader.digest.hexdigest()
                        after = os.fstat(source.fileno())
                if (source_hash != copied_hash
                        or (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns)):
                    raise RuntimeError('Source changed while copying: ' + relative)
                record.update(kind='file', bytes=before.st_size, sha256=source_hash)
                expected[relative] = source_hash
            else:
                raise RuntimeError('Unsupported special file: ' + relative)
            records.append(record)
        manifest = {'source_root': SOURCE, 'selected': list(SELECTED),
                    'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                    'records': records, 'symlinks_followed': False,
                    'source_modified': False, 'export_performed': False}
        with open(manifest_path, 'w', encoding='utf-8') as stream:
            json.dump(manifest, stream, ensure_ascii=True, indent=2, sort_keys=True)
            stream.write('\n')
        archive.add(manifest_path, arcname='__snapshot__/source_manifest.json', recursive=False)
    checked = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        names = set()
        for member in archive:
            if member.name in names:
                raise RuntimeError('Duplicate archive member: ' + member.name)
            names.add(member.name)
            if (member.isfile() or member.islnk()) and not member.name.startswith('__snapshot__/'):
                with archive.extractfile(member) as stream:
                    actual_hash = digest_stream(stream)
                if expected.get(member.name) != actual_hash:
                    raise RuntimeError('Archive mismatch: ' + member.name)
                checked.add(member.name)
    if checked != set(expected):
        raise RuntimeError('Archive file coverage mismatch')
    archive_hash = digest_file(archive_path)
    manifest_hash = digest_file(manifest_path)
    summary = {'status': 'SNAPSHOT_VERIFIED', 'staging': staging,
               'archive': archive_path, 'archive_bytes': os.path.getsize(archive_path),
               'archive_sha256': archive_hash, 'manifest_sha256': manifest_hash,
               'files_verified': len(checked), 'entries': len(records),
               'source_bytes': sum(record.get('bytes', 0) for record in records),
               'links': sum(record['kind'] == 'symlink' for record in records),
               'source_modified': False, 'export_performed': False}
    with open(os.path.join(staging, 'verification.json'), 'w') as stream:
        json.dump(summary, stream, indent=2, sort_keys=True)
        stream.write('\n')
    with open(os.path.join(staging, 'SHA256SUMS'), 'w') as stream:
        stream.write(archive_hash + '  public_rtl_sram.tar.gz\n')
        stream.write(manifest_hash + '  source_manifest.json\n')
    print(json.dumps(summary, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
