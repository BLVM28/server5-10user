#!/usr/bin/env python3
"""Read-only Linux inventory. Root is fixed; symlinks are never followed.

Run only after placing this script in the authorised home directory:
  cd /storage2/2026contest/server5/s5_10usr && python3 inventory_home.py
No downloads, remote writes, environment reads, or external commands occur.
"""
import argparse
import errno
import hashlib
import json
import os
import stat
import sys
import zipfile

ROOT = "/storage2/2026contest/server5/s5_10usr"
EXTENSIONS = {
    ".v", ".sv", ".vh", ".svh", ".f", ".flist", ".lst", ".tcl",
    ".sdc", ".upf", ".c", ".h", ".s", ".ld", ".lds", ".mk",
    ".sh", ".csh", ".tcsh", ".py", ".md", ".txt", ".pdf", ".docx",
    ".zip", ".tar", ".gz", ".tgz", ".xz", ".bz2", ".mem", ".memh",
    ".hex", ".coe", ".json", ".yaml", ".yml", ".npz", ".npy", ".wav",
}
NAMES = {"makefile", "gnumakefile", "readme", "license", "copying", "config"}
SKIP_DIRS = {
    ".ssh", ".vnc", ".config", ".cache", ".local", ".git", ".mozilla",
    "node_modules", "__pycache__", "csrc", "simv.daidir", "xcelium.d",
}


def emit(record):
    print(json.dumps(record, ensure_ascii=True, sort_keys=True), flush=True)


def useful(name):
    return name.lower() in NAMES or os.path.splitext(name)[1].lower() in EXTENSIONS


def zip_members(stream, relative):
    """List archive names only. Never extract or execute archived files."""
    try:
        with zipfile.ZipFile(stream) as archive:
            for item in archive.infolist():
                if not item.is_dir() and useful(item.filename.rsplit("/", 1)[-1]):
                    emit({"kind": "zip_member", "archive": relative,
                          "member": item.filename, "bytes": item.file_size})
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        emit({"kind": "error", "path": relative,
              "reason": type(exc).__name__})


def walk(directory_fd, relative, args, counters, depth=0):
    if depth > 24:
        emit({"kind": "skip", "path": relative, "reason": "depth_limit"})
        return
    # fd-relative traversal plus O_NOFOLLOW closes the usual symlink escape.
    with os.scandir(directory_fd) as entries:
        names = sorted(entry.name for entry in entries)
    for name in names:
        path = relative + "/" + name if relative else name
        try:
            info = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                emit({"kind": "skip", "path": path, "reason": "symlink"})
                continue
            if stat.S_ISDIR(info.st_mode):
                if name.startswith(".") or name in SKIP_DIRS:
                    continue
                child_fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                   dir_fd=directory_fd)
                try:
                    walk(child_fd, path, args, counters, depth + 1)
                finally:
                    os.close(child_fd)
                continue
            if not stat.S_ISREG(info.st_mode) or name.startswith(".") or not useful(name):
                continue
            counters["files"] += 1
            counters["bytes"] += info.st_size
            if counters["files"] > 100000:
                raise RuntimeError("file count limit exceeded")
            record = {"kind": "file", "path": path, "bytes": info.st_size,
                      "mtime_ns": info.st_mtime_ns}
            if args.hash or (args.zip_index and name.lower().endswith(".zip")):
                file_fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                                  dir_fd=directory_fd)
                with os.fdopen(file_fd, "rb") as source:
                    before = os.fstat(source.fileno())
                    if (not stat.S_ISREG(before.st_mode)
                            or (before.st_dev, before.st_ino) != (info.st_dev, info.st_ino)):
                        raise RuntimeError("file changed during inventory")
                    if args.hash:
                        digest = hashlib.sha256()
                        for block in iter(lambda: source.read(1024 * 1024), b""):
                            digest.update(block)
                        after = os.fstat(source.fileno())
                        if (after.st_size, after.st_mtime_ns) != (before.st_size, before.st_mtime_ns):
                            raise RuntimeError("file changed during hashing")
                        record["sha256"] = digest.hexdigest()
                    emit(record)
                    if args.zip_index and name.lower().endswith(".zip"):
                        source.seek(0)
                        zip_members(source, path)
            else:
                emit(record)
        except OSError as exc:
            emit({"kind": "skip", "path": path,
                  "reason": errno.errorcode.get(exc.errno, "OS_ERROR")})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hash", action="store_true", help="also read useful files for SHA-256")
    parser.add_argument("--zip-index", action="store_true", help="also list ZIP members without extraction")
    args = parser.parse_args()
    if not sys.platform.startswith("linux") or not hasattr(os, "O_NOFOLLOW"):
        raise SystemExit("REFUSED: requires Linux fd-relative O_NOFOLLOW traversal")
    if os.path.realpath(ROOT) != ROOT or os.path.realpath(os.getcwd()) != ROOT:
        raise SystemExit("REFUSED: actual cwd and root must both equal the authorised root")
    root_fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    counters = {"files": 0, "bytes": 0}
    emit({"kind": "start", "root": ROOT, "mode": "read_only_no_symlinks"})
    try:
        walk(root_fd, "", args, counters)
    finally:
        os.close(root_fd)
    emit({"kind": "finish", **counters})


if __name__ == "__main__":
    main()
