"""仅核算架构的地址覆盖和容量；不是 RTL 仿真或数值精度验证。"""
import json
from pathlib import Path

M, K, N, P = 99, 64, 256, 8
x_addresses = [m * K + k for m in range(M) for k in range(K)]
assert len(set(x_addresses)) == M * K
assert max(a // 1024 for a in x_addresses) == 6
assert all(0 <= a % 1024 < 1024 for a in x_addresses)

w_addresses, b_addresses, y_addresses = [], [], []
w_words, y_words = [], []
for g in range(N // P):
    for k in range(K):
        for j in range(P // 2):
            a = 2 * (k * N + g * P + 2 * j)
            assert a % 4 == 0
            w_words.append(a)
        for lane in range(P):
            w_addresses.append(k * N + g * P + lane)
    b_addresses.extend(g * P + lane for lane in range(P))
    for m in range(M):
        for j in range(P // 2):
            a = 2 * (m * N + g * P + 2 * j)
            assert a % 4 == 0
            y_words.append(a)
        y_addresses.extend(m * N + g * P + lane for lane in range(P))

assert sorted(w_addresses) == list(range(K * N))
assert sorted(b_addresses) == list(range(N))
assert sorted(y_addresses) == list(range(M * N))
assert sorted(w_words) == list(range(0, K * N * 2, 4))
assert sorted(y_words) == list(range(0, M * N * 2, 4))
graph_vars = json.loads((Path(__file__).parent / 'graph变量形状.json').read_text(encoding='utf-8'))
assert sum(v['dims'] == [64, 256] for v in graph_vars) == 12
assert sum(v['dims'] == [256] for v in graph_vars) == 12

report = {
    'scope': 'architecture arithmetic and address enumeration only; NOT RTL/SoC/NRMSE/PPA validation',
    'checks': 'PASS: full unique W/b/Y coverage, aligned word addresses, X bank range, 12 graph FFN1 shapes',
    'shape_M_K_N': [M, K, N],
    'parallel_lanes': P,
    'output_groups': N // P,
    'row_group_operations': M * (N // P),
    'mac_operations': M * K * N,
    'ideal_mac_issue_cycles': M * K * N // P,
    'ideal_issue_time_ms_at_150MHz': (M * K * N // P) / 150_000,
    'logical_bytes': {'X': M * K * 2, 'W': K * N * 2, 'b': N * 4, 'Y': M * N * 2},
    'payload_bytes': (M * K + K * N + M * N) * 2 + N * 4,
    'payload_32bit_transactions': {'X_read': M * K // 2, 'W_read': K * N // 2, 'b_read': N, 'Y_write': M * N // 2},
    'payload_32bit_transactions_total': ((M * K + K * N + M * N) * 2 + N * 4) // 4,
    'proposed_sram_bytes': 7 * 1024 * 2 + 8 * 128 * 2,
    'all_SP1024_fallback_sram_bytes': (7 + 8) * 1024 * 2,
    'macro_counts': {'SP1024X16': 7, 'SP128X16': 8},
    'internal_X_16bit_reads': M * K * (N // P),
    'internal_W_16bit_reads': M * K * N,
}
(Path(__file__).parent / '架构核算结果.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
